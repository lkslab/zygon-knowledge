
######## snakemake preamble start (automatically inserted, do not edit) ########
import sys; sys.path.extend(['/home/lukas/Desktop/earth/pypsa-earth/.pixi/envs/default/lib/python3.11/site-packages', '/home/lukas/.cache/snakemake/snakemake/source-cache/runtime-cache/tmpyz1z_33e/file/home/lukas/Desktop/earth/pypsa-earth/scripts', '/home/lukas/Desktop/earth/pypsa-earth/scripts']); import pickle; snakemake = pickle.loads(b'\x80\x04\x95q\xbc\x00\x00\x00\x00\x00\x00\x8c\x10snakemake.script\x94\x8c\tSnakemake\x94\x93\x94)\x81\x94}\x94(\x8c\x05input\x94\x8c\x0csnakemake.io\x94\x8c\nInputFiles\x94\x93\x94)\x81\x94\x8c\x15data/eez/eez_v11.gpkg\x94a}\x94(\x8c\x06_names\x94}\x94\x8c\x03eez\x94K\x00N\x86\x94s\x8c\x12_allowed_overrides\x94]\x94(\x8c\x05index\x94\x8c\x04sort\x94eh\x12\x8c\tfunctools\x94\x8c\x07partial\x94\x93\x94h\x06\x8c\x19Namedlist._used_attribute\x94\x93\x94\x85\x94R\x94(h\x18)}\x94\x8c\x05_name\x94h\x12sNt\x94bh\x13h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x13sNt\x94bh\x0eh\nub\x8c\x06output\x94h\x06\x8c\x0bOutputFiles\x94\x93\x94)\x81\x94(\x8c.resources/Russia/shapes/country_shapes.geojson\x94\x8c/resources/Russia/shapes/offshore_shapes.geojson\x94\x8c6resources/Russia/shapes/extended_country_shape.geojson\x94\x8c+resources/Russia/shapes/gadm_shapes.geojson\x94\x8c0resources/Russia/shapes/subregion_shapes.geojson\x94\x8c2resources/Russia/shapes/subregion_offshore.geojson\x94e}\x94(h\x0c}\x94(\x8c\x0ecountry_shapes\x94K\x00N\x86\x94\x8c\x0foffshore_shapes\x94K\x01N\x86\x94\x8c\x16extended_country_shape\x94K\x02N\x86\x94\x8c\x0bgadm_shapes\x94K\x03N\x86\x94\x8c\x10subregion_shapes\x94K\x04N\x86\x94\x8c\x12subregion_offshore\x94K\x05N\x86\x94uh\x10]\x94(h\x12h\x13eh\x12h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x12sNt\x94bh\x13h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x13sNt\x94bh.h&h0h\'h2h(h4h)h6h*h8h+ub\x8c\x06params\x94h\x06\x8c\x06Params\x94\x93\x94)\x81\x94(}\x94(\x8c\rgadm_layer_id\x94K\x01\x8c\x12simplify_tolerance\x94G?\x84z\xe1G\xae\x14{\x8c\rsimplify_gadm\x94\x88\x8c\x07minarea\x94G?\x84z\xe1G\xae\x14{\x8c\x0bupdate_file\x94\x89\x8c\x0bout_logging\x94\x88\x8c\x04year\x94M\xe4\x07\x8c\nnprocesses\x94K\x03\x8c\x0fworldpop_method\x94\x8c\x08standard\x94\x8c\ngdp_method\x94\x8c\x08standard\x94\x8c\x0econtended_flag\x94\x8c\x0eset_by_country\x94u}\x94(\x8c\x07geo_crs\x94\x8c\tEPSG:4326\x94\x8c\x0cdistance_crs\x94\x8c\tEPSG:3857\x94\x8c\x08area_crs\x94\x8c\nESRI:54009\x94u]\x94\x8c\x02RU\x94a}\x94(\x8c\x06method\x94\x89\x8c\x08apply_on\x94]\x94(\x8c\x10simplify_network\x94\x8c\x0fcluster_network\x94e\x8c\x0edefine_by_gadm\x94\x89\x8c\x12path_custom_shapes\x94\x89\x8c\x14path_custom_offshore\x94\x89\x8c\ttolerance\x94Kdue}\x94(h\x0c}\x94(\x8c\x13build_shape_options\x94K\x00N\x86\x94\x8c\x03crs\x94K\x01N\x86\x94\x8c\tcountries\x94K\x02N\x86\x94\x8c\tsubregion\x94K\x03N\x86\x94uh\x10]\x94(h\x12h\x13eh\x12h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x12sNt\x94bh\x13h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x13sNt\x94bhkhGhmhVhoh]hqh_ub\x8c\twildcards\x94h\x06\x8c\tWildcards\x94\x93\x94)\x81\x94}\x94(h\x0c}\x94h\x10]\x94(h\x12h\x13eh\x12h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x12sNt\x94bh\x13h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x13sNt\x94bub\x8c\x07threads\x94K\x01\x8c\tresources\x94h\x06\x8c\tResources\x94\x93\x94)\x81\x94(K\x01K\x01\x8c\x04/tmp\x94M\x18\x0cM\x89\x0be}\x94(h\x0c}\x94(\x8c\x06_cores\x94K\x00N\x86\x94\x8c\x06_nodes\x94K\x01N\x86\x94\x8c\x06tmpdir\x94K\x02N\x86\x94\x8c\x06mem_mb\x94K\x03N\x86\x94\x8c\x07mem_mib\x94K\x04N\x86\x94uh\x10]\x94(h\x12h\x13eh\x12h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x12sNt\x94bh\x13h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x13sNt\x94bh\x93K\x01h\x95K\x01h\x97h\x90h\x99M\x18\x0ch\x9bM\x89\x0bub\x8c\x03log\x94h\x06\x8c\x03Log\x94\x93\x94)\x81\x94\x8c\x1clogs/Russia/build_shapes.log\x94a}\x94(h\x0c}\x94h\x10]\x94(h\x12h\x13eh\x12h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x12sNt\x94bh\x13h\x16h\x18\x85\x94R\x94(h\x18)}\x94h\x1ch\x13sNt\x94bub\x8c\x06config\x94}\x94(\x8c\x07version\x94\x8c\x050.8.0\x94\x8c\x08tutorial\x94\x89\x8c\x07logging\x94}\x94(\x8c\x05level\x94\x8c\x04INFO\x94\x8c\x06format\x94\x8c"%(levelname)s:%(name)s:%(message)s\x94u\x8c\x0bresults_dir\x94\x8c\x08results/\x94\x8c\x0bsummary_dir\x94\x8c\x08results/\x94\x8c\tforesight\x94\x8c\tovernight\x94\x8c\tcountries\x94]\x94h^a\x8c\x06enable\x94}\x94(\x8c\x13retrieve_databundle\x94\x88\x8c\x1aretrieve_databundle_sector\x94\x89\x8c\x12retrieve_cost_data\x94\x88\x8c\x0fretrieve_cutout\x94\x89\x8c\x11download_osm_data\x94\x88\x8c\x19download_global_buildings\x94\x89\x8c\x13build_natura_raster\x94\x89\x8c\x0cbuild_cutout\x94\x89\x8c\x0cprogress_bar\x94\x88\x8c\rcustom_busmap\x94\x89u\x8c\x0ccustom_rules\x94]\x94\x8c\x03run\x94}\x94(\x8c\x04name\x94\x8c\x06Russia\x94\x8c\x0bsector_name\x94\x8c\x00\x94\x8c\x0eshared_cutouts\x94\x88\x8c\x16allow_scenario_failure\x94\x89\x8c\x0bbase_config\x94\x8c\x13config.default.yaml\x94u\x8c\x08scenario\x94}\x94(\x8c\x05simpl\x94]\x94h\xdca\x8c\x02ll\x94]\x94\x8c\x04copt\x94a\x8c\x08clusters\x94]\x94\x8c\x07300flex\x94a\x8c\x04opts\x94]\x94\x8c\x04Co2L\x94a\x8c\x11planning_horizons\x94]\x94M\xee\x07a\x8c\x05sopts\x94]\x94\x8c\x04144h\x94a\x8c\x06demand\x94]\x94\x8c\x02AB\x94a\x8c\x03unc\x94]\x94(\x8c\x02m0\x94\x8c\x02m1\x94\x8c\x02m2\x94\x8c\x02m3\x94\x8c\x02m4\x94\x8c\x02m5\x94\x8c\x02m6\x94\x8c\x02m7\x94\x8c\x02m8\x94eu\x8c\tsnapshots\x94}\x94(\x8c\x05start\x94\x8c\n2013-01-01\x94\x8c\x03end\x94\x8c\n2014-01-01\x94\x8c\tinclusive\x94\x8c\x04left\x94u\x8c\x03crs\x94hV\x8c\x06natura\x94}\x94(\x8c\x0bnatura_size\x94\x8c\tcountries\x94\x8c\x11natura_resolution\x94Kd\x8c\x0bwindow_size\x94M\x10\'\x8c\x0bbuffer_size\x94M\x10\'u\x8c\x19augmented_line_connection\x94}\x94(\x8c\x10add_to_snakefile\x94\x89\x8c\x14connectivity_upgrade\x94K\x02\x8c\rnew_line_type\x94]\x94\x8c\x04HVAC\x94a\x8c\rmin_expansion\x94K\x01\x8c\rmin_DC_length\x94MX\x02u\x8c\x0fcluster_options\x94}\x94(\x8c\x10simplify_network\x94}\x94(\x8c\x0eto_substations\x94\x89\x8c\talgorithm\x94\x8c\x06kmeans\x94\x8c\x07feature\x94\x8c\x11solar+onwind-time\x94\x8c\x10exclude_carriers\x94]\x94\x8c\x0cremove_stubs\x94\x88\x8c\x1bremove_stubs_across_borders\x94\x89\x8c\x19p_threshold_drop_isolated\x94K\x14\x8c\x1ap_threshold_merge_isolated\x94M,\x01\x8c\x1as_threshold_fetch_isolated\x94\x89u\x8c\x0fcluster_network\x94}\x94(\x8c\talgorithm\x94\x8c\x06kmeans\x94\x8c\x07feature\x94\x8c\x11solar+onwind-time\x94\x8c\x10exclude_carriers\x94]\x94u\x8c\x16alternative_clustering\x94\x89\x8c\x12distribute_cluster\x94]\x94\x8c\x04load\x94a\x8c\x0bout_logging\x94\x88\x8c\x16aggregation_strategies\x94}\x94(\x8c\ngenerators\x94}\x94(\x8c\x05p_nom\x94\x8c\x03sum\x94\x8c\tp_nom_max\x94\x8c\x03sum\x94\x8c\tp_nom_min\x94\x8c\x03sum\x94\x8c\x08p_min_pu\x94\x8c\x04mean\x94\x8c\x08p_max_pu\x94\x8c\x10weighted_average\x94\x8c\rmarginal_cost\x94\x8c\x04mean\x94\x8c\x0bcommittable\x94\x8c\x03any\x94\x8c\rramp_limit_up\x94\x8c\x03max\x94\x8c\x0framp_limit_down\x94\x8c\x03max\x94\x8c\nefficiency\x94\x8c\x04mean\x94\x8c\nbuild_year\x94\x8c\x04mean\x94\x8c\x08lifetime\x94\x8c\x04mean\x94u\x8c\tone_ports\x94}\x94\x8c\x0bStorageUnit\x94}\x94(\x8c\nbuild_year\x94\x8c\x04mean\x94\x8c\x08lifetime\x94\x8c\x04mean\x94usu\x8c\rfocus_weights\x94\x89u\x8c\x13build_shape_options\x94hG\x8c\tsubregion\x94h_\x8c\x16clean_osm_data_options\x94}\x94(\x8c\x0fnames_by_shapes\x94\x88\x8c\x11threshold_voltage\x94M8\xc7\x8c\x0etag_substation\x94\x8c\x0ctransmission\x94\x8c\x10add_line_endings\x94\x88\x8c\x15generator_name_method\x94\x8c\x03OSM\x94\x8c\x10use_custom_lines\x94\x8c\x08OSM_only\x94\x8c\x11path_custom_lines\x94\x89\x8c\x16use_custom_substations\x94\x8c\x08OSM_only\x94\x8c\x17path_custom_substations\x94\x89\x8c\x11use_custom_cables\x94\x8c\x08OSM_only\x94\x8c\x12path_custom_cables\x94\x89u\x8c\x11build_osm_network\x94}\x94(\x8c\x11group_close_buses\x94\x88\x8c\x15group_tolerance_buses\x94M\x88\x13\x8c\x17split_overpassing_lines\x94\x88\x8c\x1boverpassing_lines_tolerance\x94K\x01\x8c\x08force_ac\x94\x89u\x8c\x0cbase_network\x94}\x94(\x8c\x1fmin_voltage_substation_offshore\x94M8\xc7\x8c\x1amin_voltage_rebase_voltage\x94M8\xc7u\x8c\x0cload_options\x94}\x94(\x8c\x06source\x94\x8c\x05gegis\x94\x8c\x0cweather_year\x94M\xdd\x07\x8c\x0fprediction_year\x94M\xee\x07\x8c\x05scale\x94K\x01u\x8c\nco2_budget\x94}\x94(\x8c\x06enable\x94\x89\x8c\x0foverride_co2opt\x94\x88\x8c\rco2base_value\x94\x8c\x08co2limit\x94\x8c\x04year\x94}\x94(M\xe4\x07G?\xf0\x00\x00\x00\x00\x00\x00M\xe9\x07G?\xeb333333M\xee\x07G?\xe6ffffffM\xf3\x07G?\xe1\x99\x99\x99\x99\x99\x9aM\xf8\x07G?\xd9\x99\x99\x99\x99\x99\x9aM\xfd\x07G?\xd0\x00\x00\x00\x00\x00\x00M\x02\x08G?\xb9\x99\x99\x99\x99\x99\x9auu\x8c\x0belectricity\x94}\x94(\x8c\x0cbase_voltage\x94G@w\xc0\x00\x00\x00\x00\x00\x8c\x08voltages\x94]\x94(G@`\x80\x00\x00\x00\x00\x00G@k\x80\x00\x00\x00\x00\x00G@r\xc0\x00\x00\x00\x00\x00G@w\xc0\x00\x00\x00\x00\x00G@\x7f@\x00\x00\x00\x00\x00G@\x87p\x00\x00\x00\x00\x00e\x8c\x08co2limit\x94GA\x92z9\x80\x00\x00\x00\x8c\x07co2base\x94GA\xd6(tp\x00\x00\x00\x8c\x10agg_p_nom_limits\x94}\x94(\x8c\x04file\x94\x8c\x19data/agg_p_nom_minmax.csv\x94\x8c\x10include_existing\x94\x89u\x8c\rhvdc_as_lines\x94\x89\x8c\x12automatic_emission\x94\x89\x8c\x1cautomatic_emission_base_year\x94M\xc6\x07\x8c\x13operational_reserve\x94}\x94(\x8c\x08activate\x94\x89\x8c\x0cepsilon_load\x94G?\x94z\xe1G\xae\x14{\x8c\x0cepsilon_vres\x94G?\x94z\xe1G\xae\x14{\x8c\x0bcontingency\x94K\x00u\x8c\tmax_hours\x94}\x94(\x8c\x07battery\x94K\x06\x8c\x02H2\x94K\xa8u\x8c\x13extendable_carriers\x94}\x94(\x8c\tGenerator\x94]\x94(\x8c\x05solar\x94\x8c\x06onwind\x94\x8c\noffwind-ac\x94\x8c\noffwind-dc\x94\x8c\x04OCGT\x94e\x8c\x0bStorageUnit\x94]\x94\x8c\x05Store\x94]\x94(\x8c\x07battery\x94\x8c\x02H2\x94e\x8c\x04Link\x94]\x94u\x8c\x12powerplants_filter\x94\x8cP(DateOut >= 2022 or DateOut != DateOut) and (DateIn <= 2023 or DateIn != DateIn)\x94\x8c\x12custom_powerplants\x94\x89\x8c\x15conventional_carriers\x94]\x94(\x8c\x07nuclear\x94\x8c\x03oil\x94\x8c\x04OCGT\x94\x8c\x04CCGT\x94\x8c\x04coal\x94\x8c\x07lignite\x94\x8c\ngeothermal\x94\x8c\x07biomass\x94e\x8c\x12renewable_carriers\x94]\x94(\x8c\x05solar\x94\x8c\x06onwind\x94\x8c\noffwind-ac\x94\x8c\noffwind-dc\x94\x8c\x05hydro\x94e\x8c\x1destimate_renewable_capacities\x94}\x94(\x8c\x05stats\x94\x8c\x05irena\x94\x8c\x04year\x94M\xe7\x07\x8c\tp_nom_min\x94K\x01\x8c\tp_nom_max\x94\x89\x8c\x12technology_mapping\x94}\x94(\x8c\x08Offshore\x94]\x94(\x8c\noffwind-ac\x94\x8c\noffwind-dc\x94e\x8c\x07Onshore\x94]\x94\x8c\x06onwind\x94a\x8c\x02PV\x94]\x94\x8c\x05solar\x94auuu\x8c\x05lines\x94}\x94(\x8c\x08ac_types\x94}\x94(G@`\x80\x00\x00\x00\x00\x00\x8c\x14243-AL1/39-ST1A 20.0\x94G@k\x80\x00\x00\x00\x00\x00\x8c\x1bAl/St 240/40 2-bundle 220.0\x94G@r\xc0\x00\x00\x00\x00\x00\x8c\x1bAl/St 240/40 3-bundle 300.0\x94G@w\xc0\x00\x00\x00\x00\x00\x8c\x1bAl/St 240/40 4-bundle 380.0\x94G@\x7f@\x00\x00\x00\x00\x00\x8c\x1bAl/St 240/40 4-bundle 380.0\x94G@\x87p\x00\x00\x00\x00\x00\x8c\x1bAl/St 560/50 4-bundle 750.0\x94u\x8c\x08dc_types\x94}\x94G@\x7f@\x00\x00\x00\x00\x00\x8c\x0eHVDC XLPE 1000\x94s\x8c\x08s_max_pu\x94G?\xe6ffffff\x8c\ts_nom_max\x94G\x7f\xf0\x00\x00\x00\x00\x00\x00\x8c\rs_nom_max_min\x94G\xff\xf0\x00\x00\x00\x00\x00\x00\x8c\rlength_factor\x94G?\xf4\x00\x00\x00\x00\x00\x00\x8c\x12under_construction\x94\x8c\x04zero\x94u\x8c\x05links\x94}\x94(\x8c\x08p_max_pu\x94G?\xf0\x00\x00\x00\x00\x00\x00\x8c\tp_nom_max\x94G\x7f\xf0\x00\x00\x00\x00\x00\x00\x8c\rp_nom_max_min\x94G\xff\xf0\x00\x00\x00\x00\x00\x00\x8c\x12under_construction\x94\x8c\x04zero\x94u\x8c\x0ctransformers\x94}\x94(\x8c\x01x\x94G?\xb9\x99\x99\x99\x99\x99\x9a\x8c\x05s_nom\x94G@\x9f@\x00\x00\x00\x00\x00\x8c\x04type\x94h\xdcu\x8c\x06atlite\x94}\x94(\x8c\nnprocesses\x94K\x04\x8c\x07cutouts\x94}\x94(\x8c\x10cutout-2013-era5\x94}\x94(\x8c\x06module\x94\x8c\x04era5\x94\x8c\x02dx\x94G?\xd3333333\x8c\x02dy\x94G?\xd3333333u\x8c\x1dcutout-2013-era5-northeurasia\x94}\x94(\x8c\x06module\x94\x8c\x04era5\x94\x8c\x02dx\x94G?\xd3333333\x8c\x02dy\x94G?\xd3333333uu\x8c\x07default\x94\x8c\x1dcutout-2013-era5-northeurasia\x94u\x8c\trenewable\x94}\x94(\x8c\x06onwind\x94}\x94(\x8c\x06cutout\x94\x8c\x1dcutout-2013-era5-northeurasia\x94\x8c\x08resource\x94}\x94(\x8c\x06method\x94\x8c\x04wind\x94\x8c\x07turbine\x94\x8c\x0fVestas_V112_3MW\x94u\x8c\x11capacity_per_sqkm\x94K\x03\x8c\ncopernicus\x94}\x94(\x8c\ngrid_codes\x94]\x94(K\x14K\x1eK(K<KdKoKpKqKrKsKtKyKzK{K|K}K~e\x8c\x08distance\x94M\xe8\x03\x8c\x13distance_grid_codes\x94]\x94K2au\x8c\x06natura\x94\x88\x8c\tpotential\x94\x8c\x06simple\x94\x8c\rclip_p_max_pu\x94G?\x84z\xe1G\xae\x14{\x8c\nextendable\x94\x88u\x8c\noffwind-ac\x94}\x94(\x8c\x06cutout\x94\x8c\x1dcutout-2013-era5-northeurasia\x94\x8c\x08resource\x94}\x94(\x8c\x06method\x94\x8c\x04wind\x94\x8c\x07turbine\x94\x8c"NREL_ReferenceTurbine_5MW_offshore\x94u\x8c\x11capacity_per_sqkm\x94K\x02\x8c\ncopernicus\x94}\x94\x8c\ngrid_codes\x94]\x94(KPK\xc8es\x8c\x06natura\x94\x88\x8c\tmax_depth\x94K2\x8c\x12max_shore_distance\x94M0u\x8c\tpotential\x94\x8c\x06simple\x94\x8c\rclip_p_max_pu\x94G?\x84z\xe1G\xae\x14{\x8c\nextendable\x94\x88u\x8c\noffwind-dc\x94}\x94(\x8c\x06cutout\x94\x8c\x1dcutout-2013-era5-northeurasia\x94\x8c\x08resource\x94}\x94(\x8c\x06method\x94\x8c\x04wind\x94\x8c\x07turbine\x94\x8c"NREL_ReferenceTurbine_5MW_offshore\x94u\x8c\x11capacity_per_sqkm\x94K\x03\x8c\ncopernicus\x94}\x94\x8c\ngrid_codes\x94]\x94(KPK\xc8es\x8c\x06natura\x94\x88\x8c\tmax_depth\x94K2\x8c\x12min_shore_distance\x94M0u\x8c\tpotential\x94\x8c\x06simple\x94\x8c\rclip_p_max_pu\x94G?\x84z\xe1G\xae\x14{\x8c\nextendable\x94\x88u\x8c\x05solar\x94}\x94(\x8c\x06cutout\x94\x8c\x1dcutout-2013-era5-northeurasia\x94\x8c\x08resource\x94}\x94(\x8c\x06method\x94\x8c\x02pv\x94\x8c\x05panel\x94\x8c\x03CSi\x94\x8c\x0borientation\x94\x8c\x10latitude_optimal\x94u\x8c\x11capacity_per_sqkm\x94G@\x12ffffff\x8c\x11correction_factor\x94G?\xebV\xba\x8cXhw\x8c\ncopernicus\x94}\x94\x8c\ngrid_codes\x94]\x94(K\x14K\x1eK(K2K<KZKdes\x8c\x06natura\x94\x88\x8c\tpotential\x94\x8c\x06simple\x94\x8c\rclip_p_max_pu\x94G?\x84z\xe1G\xae\x14{\x8c\nextendable\x94\x88u\x8c\x05hydro\x94}\x94(\x8c\x06cutout\x94\x8c\x1dcutout-2013-era5-northeurasia\x94\x8c\x11hydrobasins_level\x94K\x06\x8c\x08resource\x94}\x94(\x8c\x06method\x94\x8c\x05hydro\x94\x8c\x0bhydrobasins\x94\x8c data/hydrobasins/hybas_world.shp\x94\x8c\tflowspeed\x94G?\xf0\x00\x00\x00\x00\x00\x00u\x8c\x08carriers\x94]\x94(\x8c\x03ror\x94\x8c\x03PHS\x94\x8c\x05hydro\x94e\x8c\rPHS_max_hours\x94K\x06\x8c\x0fhydro_max_hours\x94\x8c!energy_capacity_totals_by_country\x94\x8c\x17hydro_max_hours_default\x94G@\x18\x00\x00\x00\x00\x00\x00\x8c\x0fclip_min_inflow\x94G?\xf0\x00\x00\x00\x00\x00\x00\x8c\nextendable\x94\x88\x8c\rnormalization\x94}\x94(\x8c\x06method\x94\x8c\x05irena\x94\x8c\x04year\x94M\xe7\x07u\x8c\nmultiplier\x94G?\xf1\x99\x99\x99\x99\x99\x9a\x8c\x13hydro_min_inflow_pu\x94G?\xf0\x00\x00\x00\x00\x00\x00u\x8c\x03csp\x94}\x94(\x8c\x06cutout\x94\x8c\x1dcutout-2013-era5-northeurasia\x94\x8c\x08resource\x94}\x94(\x8c\x06method\x94\x8c\x03csp\x94\x8c\x0cinstallation\x94\x8c\x0fSAM_solar_tower\x94u\x8c\x11capacity_per_sqkm\x94G@\x03"\xd0\xe5`A\x89\x8c\ncopernicus\x94}\x94(\x8c\ngrid_codes\x94]\x94(K\x14K\x1eK(K<KZe\x8c\x10distancing_codes\x94]\x94K2a\x8c\x11distance_to_codes\x94M\xb8\x0bu\x8c\x06natura\x94\x88\x8c\tpotential\x94\x8c\x06simple\x94\x8c\rclip_p_max_pu\x94G?\x84z\xe1G\xae\x14{\x8c\nextendable\x94\x88\x8c\tcsp_model\x94\x8c\x08advanced\x94uu\x8c\x05costs\x94}\x94(\x8c\x04year\x94M\xee\x07\x8c\x17technology_data_version\x94\x8c\x07v0.13.2\x94\x8c\x0cdiscountrate\x94]\x94G?\xb2-\x0eV\x04\x18\x93a\x8c\x15country_specific_data\x94h\xdc\x8c\rcost_scenario\x94\x8c\x08moderate\x94\x8c\x0efinancial_case\x94\x8c\x06market\x94\x8c\x0foutput_currency\x94\x8c\x03EUR\x94\x8c\x15default_exchange_rate\x94G?\xe8\x1a6\xe2\xeb\x1cC\x8c\x1dfuture_exchange_rate_strategy\x94\x8c\treference\x94\x8c\x1bcustom_future_exchange_rate\x94\x8c\x04None\x94\x8c\rrooftop_share\x94G?\xc1\xeb\x85\x1e\xb8Q\xec\x8c\x0bfill_values\x94}\x94(\x8c\x03FOM\x94K\x00\x8c\x03VOM\x94K\x00\x8c\nefficiency\x94K\x01\x8c\x04fuel\x94K\x00\x8c\ninvestment\x94K\x00\x8c\x08lifetime\x94K\x19\x8c\rCO2 intensity\x94K\x00\x8c\rdiscount rate\x94G?\xb1\xeb\x85\x1e\xb8Q\xecu\x8c\rmarginal_cost\x94}\x94(\x8c\x05solar\x94G?\x84z\xe1G\xae\x14{\x8c\x06onwind\x94G?\x8e\xb8Q\xeb\x85\x1e\xb8\x8c\x07offwind\x94G?\x8e\xb8Q\xeb\x85\x1e\xb8\x8c\x05hydro\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x02H2\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x0celectrolysis\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\tfuel cell\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07battery\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x10battery inverter\x94G\x00\x00\x00\x00\x00\x00\x00\x00u\x8c\x0femission_prices\x94}\x94\x8c\x03co2\x94G\x00\x00\x00\x00\x00\x00\x00\x00s\x8c\x05lines\x94}\x94\x8c\rlength_factor\x94G?\xf4\x00\x00\x00\x00\x00\x00su\x8c\x0bmonte_carlo\x94}\x94(\x8c\x07options\x94}\x94(\x8c\x10add_to_snakefile\x94\x89\x8c\x07samples\x94K\t\x8c\x11sampling_strategy\x94\x8c\x07chaospy\x94\x8c\x04seed\x94K*u\x8c\runcertainties\x94}\x94(\x8c\rloads_t.p_set\x94}\x94(\x8c\x04type\x94\x8c\x07uniform\x94\x8c\x04args\x94]\x94(G?\xe0\x00\x00\x00\x00\x00\x00K\x01eu\x8c>generators_t.p_max_pu.loc[:, n.generators.carrier == "onwind"]\x94}\x94(\x8c\x04type\x94\x8c\tlognormal\x94\x8c\x04args\x94]\x94G?\xf8\x00\x00\x00\x00\x00\x00au\x8c=generators_t.p_max_pu.loc[:, n.generators.carrier == "solar"]\x94}\x94(\x8c\x04type\x94\x8c\x04beta\x94\x8c\x04args\x94]\x94(G?\xe0\x00\x00\x00\x00\x00\x00K\x02euuu\x8c\rpolicy_config\x94}\x94\x8c\x08hydrogen\x94}\x94(\x8c\x11temporal_matching\x94\x8c\x14no_temporal_matching\x94\x8c\x10spatial_matching\x94\x89\x8c\x1atemporal_matching_carriers\x94]\x94(\x8c\x03csp\x94\x8c\x05solar\x94\x8c\x06onwind\x94\x8c\noffwind-ac\x94\x8c\noffwind-dc\x94\x8c\x03ror\x94\x8c\x05hydro\x94e\x8c\x15matching_technologies\x94]\x94(\x8c\x0fH2 Electrolysis\x94\x8c\x1bAlkaline electrolyzer large\x94\x8c\x1cAlkaline electrolyzer medium\x94\x8c\x1bAlkaline electrolyzer small\x94\x8c\x10PEM electrolyzer\x94\x8c\x04SOEC\x94e\x8c\radditionality\x94\x89\x8c\x0eallowed_excess\x94G?\xf0\x00\x00\x00\x00\x00\x00\x8c\x0cis_reference\x94\x89\x8c\x0eremove_h2_load\x94\x89\x8c\x0bpath_to_ref\x94h\xdc\x8c\x0fre_country_load\x94\x89us\x8c\x0bdemand_data\x94}\x94(\x8c\x0bupdate_data\x94\x88\x8c\tbase_year\x94M\xe3\x07\x8c\x10other_industries\x94\x89\x8c\x0ealuminium_year\x94M\xe3\x07u\x8c\x0ffossil_reserves\x94}\x94\x8c\x03oil\x94Kds\x8c\x06export\x94}\x94(\x8c\nendogenous\x94\x89\x8c\x10endogenous_price\x94M\x90\x01\x8c\x05store\x94\x88\x8c\x13store_capital_costs\x94\x8c\x08no_costs\x94\x8c\x08h2export\x94]\x94K\na\x8c\x0eexport_profile\x94\x8c\x04ship\x94\x8c\x04ship\x94}\x94(\x8c\rship_capacity\x94G?\xd9\x99\x99\x99\x99\x99\x9a\x8c\x0btravel_time\x94M \x01\x8c\tfill_time\x94K\x18\x8c\x0bunload_time\x94K\x18uu\x8c\x0bcustom_data\x94}\x94(\x8c\x0bheat_demand\x94\x89\x8c\x0findustry_demand\x94\x89\x8c\x11industry_database\x94\x89\x8c\x10transport_demand\x94\x89\x8c\x0bwater_costs\x94\x89\x8c\x0eh2_underground\x94\x89\x8c\x0cadd_existing\x94\x89\x8c\x0ecustom_sectors\x94\x89\x8c\x0bgas_network\x94\x89\x8c\x0cexport_ports\x94\x89\x8c\x08airports\x94\x89u\x8c\x08industry\x94}\x94\x8c\x0ereference_year\x94M\xdf\x07s\x8c\rsolar_thermal\x94}\x94(\x8c\x0eclearsky_model\x94\x8c\x06simple\x94\x8c\x0borientation\x94}\x94(\x8c\x05slope\x94G@F\x80\x00\x00\x00\x00\x00\x8c\x07azimuth\x94G@f\x80\x00\x00\x00\x00\x00uu\x8c\x13existing_capacities\x94}\x94(\x8c\x14grouping_years_power\x94]\x94(M\xa8\x07M\xad\x07M\xb2\x07M\xb7\x07M\xbc\x07M\xc1\x07M\xc6\x07M\xcb\x07M\xd0\x07M\xd5\x07M\xda\x07M\xdf\x07M\xe4\x07M\xe9\x07M\xee\x07e\x8c\x13grouping_years_heat\x94]\x94(M\xbc\x07M\xc1\x07M\xc6\x07M\xcb\x07M\xd0\x07M\xd5\x07M\xda\x07M\xdf\x07M\xe3\x07e\x8c\x12threshold_capacity\x94K\n\x8c\x18default_heating_lifetime\x94K\x14\x8c\x15conventional_carriers\x94]\x94(\x8c\x07lignite\x94\x8c\x04coal\x94\x8c\x03oil\x94\x8c\x07uranium\x94eu\x8c\x06sector\x94}\x94(\x8c\x06enable\x94}\x94(\x8c\x04heat\x94\x88\x8c\x07biomass\x94\x88\x8c\x08industry\x94\x88\x8c\x08shipping\x94\x88\x8c\x08aviation\x94\x88\x8c\x0eland_transport\x94\x88\x8c\x0erail_transport\x94\x88\x8c\x0bagriculture\x94\x88\x8c\x0bresidential\x94\x88\x8c\x08services\x94\x88u\x8c\x03gas\x94}\x94(\x8c\x0bspatial_gas\x94\x88\x8c\x07network\x94\x89\x8c\x0cnetwork_data\x94\x8c\x04GGIT\x94\x8c\x18network_data_GGIT_status\x94]\x94(\x8c\x0cConstruction\x94\x8c\tOperating\x94\x8c\x04Idle\x94\x8c\x07Shelved\x94\x8c\nMothballed\x94\x8c\x08Proposed\x94eu\x8c\x08hydrogen\x94}\x94(\x8c\x07network\x94\x88\x8c\x1cH2_retrofit_capacity_per_CH4\x94G?\xe3333333\x8c\rnetwork_limit\x94M\xd0\x07\x8c\x0enetwork_routes\x94\x8c\x03gas\x94\x8c\x17gas_network_repurposing\x94\x88\x8c\x13underground_storage\x94\x89\x8c\x0fhydrogen_colors\x94\x89\x8c\x10set_color_shares\x94\x89\x8c\nblue_share\x94G?\xd9\x99\x99\x99\x99\x99\x9a\x8c\npink_share\x94G?\xa9\x99\x99\x99\x99\x99\x9a\x8c\x17production_technologies\x94]\x94(\x8c\x0fH2 Electrolysis\x94\x8c\x03SMR\x94\x8c\x06SMR CC\x94eu\x8c\x04coal\x94}\x94(\x8c\x0cspatial_coal\x94\x88\x8c\rshift_to_elec\x94\x88u\x8c\x07lignite\x94}\x94\x8c\x0fspatial_lignite\x94\x89s\x8c\x03oil\x94}\x94\x8c\x0bspatial_oil\x94\x88s\x8c\x07ammonia\x94}\x94(\x8c\x06enable\x94\x88\x8c\x0fspatial_ammonia\x94\x88\x8c\x0fproduction_year\x94M\xe3\x07\x8c\x10gas_MWh_per_tNH3\x94G@\x1f=p\xa3\xd7\n=\x8c\x11elec_MWh_per_tNH3\x94G?\xf4r\xb0 \xc4\x9b\xa6\x8c\x0eco2_t_per_tNH3\x94G?\xf8\xc0\x83\x12n\x97\x8du\x8c\x10district_heating\x94}\x94(\x8c\tpotential\x94G?\xd3333333\x8c\x08progress\x94K\x01\x8c\x15district_heating_loss\x94G?\xc3333333u\x8c\x1dreduce_space_heat_exogenously\x94\x89\x8c$reduce_space_heat_exogenously_factor\x94G?\xd2\x8f\\(\xf5\xc2\x8f\x8c\x10space_heat_share\x94G?\xe3333333\x8c\x03tes\x94\x88\x8c\x07tes_tau\x94}\x94(\x8c\tdecentral\x94K\x03\x8c\x07central\x94K\xb4u\x8c\x07boilers\x94\x88\x8c\x0boil_boilers\x94\x89\x8c\x03chp\x94\x88\x8c\tmicro_chp\x94\x89\x8c\rsolar_thermal\x94\x88\x8c\x10heat_pump_sink_T\x94K7\x8c\x0ftime_dep_hp_cop\x94\x88\x8c\x13solar_cf_correction\x94G?\xe9;\n,\xa9\xac6\x8c\x1cbev_plug_to_wheel_efficiency\x94G?\xc9\x99\x99\x99\x99\x99\x9a\x8c\x15bev_charge_efficiency\x94G?\xec\xcc\xcc\xcc\xcc\xcc\xcd\x8c transport_heating_deadband_upper\x94G@4\x00\x00\x00\x00\x00\x00\x8c transport_heating_deadband_lower\x94G@.\x00\x00\x00\x00\x00\x00\x8c\x17ICE_lower_degree_factor\x94G?\xd8\x00\x00\x00\x00\x00\x00\x8c\x17ICE_upper_degree_factor\x94G?\xf9\x99\x99\x99\x99\x99\x9a\x8c\x16EV_lower_degree_factor\x94G?\xef\\(\xf5\xc2\x8f\\\x8c\x16EV_upper_degree_factor\x94G?\xe4(\xf5\xc2\x8f\\)\x8c\rbev_avail_max\x94G?\xeeffffff\x8c\x0ebev_avail_mean\x94G?\xe9\x99\x99\x99\x99\x99\x9a\x8c\x19bev_dsm_restriction_value\x94G?\xe8\x00\x00\x00\x00\x00\x00\x8c\x18bev_dsm_restriction_time\x94K\x07\x8c\x03v2g\x94\x88\x8c\x07bev_dsm\x94\x88\x8c\nbev_energy\x94G?\xa9\x99\x99\x99\x99\x99\x9a\x8c\x10bev_availability\x94G?\xe0\x00\x00\x00\x00\x00\x00\x8c\x1etransport_fuel_cell_efficiency\x94G?\xe0\x00\x00\x00\x00\x00\x00\x8c(transport_internal_combustion_efficiency\x94G?\xd3333333\x8c\x1eland_transport_fuel_cell_share\x94}\x94(\x8c\x07BU_2030\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07AP_2030\x94G?pbM\xd2\xf1\xa9\xfc\x8c\x07NZ_2030\x94G?\x94z\xe1G\xae\x14{\x8c\x07DF_2030\x94G?\x84z\xe1G\xae\x14{\x8c\x07AB_2030\x94G?\x84z\xe1G\xae\x14{\x8c\x07BU_2050\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07AP_2050\x94G?\xae\xb8Q\xeb\x85\x1e\xb8\x8c\x07NZ_2050\x94G?\xd1\xeb\x85\x1e\xb8Q\xec\x8c\x07DF_2050\x94G?\xb4z\xe1G\xae\x14{u\x8c\x1dland_transport_electric_share\x94}\x94(\x8c\x07BU_2030\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07AP_2030\x94G?\xb3333333\x8c\x07NZ_2030\x94G?\xc0\xa3\xd7\n=p\xa4\x8c\x07DF_2030\x94G?\x84z\xe1G\xae\x14{\x8c\x07AB_2030\x94G?\x84z\xe1G\xae\x14{\x8c\x07BU_2050\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07AP_2050\x94G?\xda\xe1G\xae\x14z\xe1\x8c\x07NZ_2050\x94G?\xe5\xc2\x8f\\(\xf5\xc3\x8c\x07DF_2050\x94G?\x86\x87+\x02\x0cI\xbau\x8c\x11dynamic_transport\x94}\x94(\x8c\x06enable\x94\x89\x8c\x1eland_transport_fuel_cell_share\x94}\x94(\x8c\x07Co2L2.0\x94G?\x84z\xe1G\xae\x14{\x8c\x07Co2L1.0\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.90\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.80\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.70\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.60\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.50\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.40\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.30\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.20\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.10\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.00\x94G?\x84z\xe1G\xae\x14{u\x8c\x1dland_transport_electric_share\x94}\x94(\x8c\x07Co2L2.0\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07Co2L1.0\x94G?\x84z\xe1G\xae\x14{\x8c\x08Co2L0.90\x94G?\x9e\xb8Q\xeb\x85\x1e\xb8\x8c\x08Co2L0.80\x94G?\xae\xb8Q\xeb\x85\x1e\xb8\x8c\x08Co2L0.70\x94G?\xb9\x99\x99\x99\x99\x99\x9a\x8c\x08Co2L0.60\x94G?\xc5\xc2\x8f\\(\xf5\xc3\x8c\x08Co2L0.50\x94G?\xd1G\xae\x14z\xe1H\x8c\x08Co2L0.40\x94G?\xd9\x99\x99\x99\x99\x99\x9a\x8c\x08Co2L0.30\x94G?\xe1\x99\x99\x99\x99\x99\x9a\x8c\x08Co2L0.20\x94G?\xe6\x14z\xe1G\xae\x14\x8c\x08Co2L0.10\x94G?\xe9\x99\x99\x99\x99\x99\x9a\x8c\x08Co2L0.00\x94G?\xec(\xf5\xc2\x8f\\)uu\x8c\x11biomass_transport\x94\x88\x8c\x1ebiomass_transport_default_cost\x94G?\xb9\x99\x99\x99\x99\x99\x9a\x8c\x17solid_biomass_potential\x94K(\x8c\x10biogas_potential\x94G?\xe0\x00\x00\x00\x00\x00\x00\x8c\x1delectricity_distribution_grid\x94\x88\x8c"enable_electricity_connection_cost\x94\x89\x8c\rsolar_rooftop\x94}\x94(\x8c\x06enable\x94\x88\x8c\tkW_per_m2\x94G?\xb9\x99\x99\x99\x99\x99\x9a\x8c\rm2_per_person\x94K\x14\x8c\x11use_building_size\x94\x89\x8c\rinstall_ratio\x94}\x94(K\x00K\x00K\nG?\xd3333333KdG?\xd7\n=p\xa3\xd7\nK\xc8G?\xda=p\xa3\xd7\n=M\xc2\x01G?\xdf\\(\xf5\xc2\x8f\\M\xfc\x08G?\xe5\x1e\xb8Q\xeb\x85\x1fu\x8c\ttolerance\x94Kdu\x8c\x0chome_battery\x94\x88\x8c\x17transmission_efficiency\x94}\x94(\x8c\x1delectricity distribution grid\x94}\x94\x8c\x11efficiency_static\x94G?\xef\n=p\xa3\xd7\ns\x8c\x0bH2 pipeline\x94}\x94(\x8c\x15efficiency_per_1000km\x94K\x01\x8c\x16compression_per_1000km\x94G?\x91hr\xb0 \xc4\x9cuu\x8c\x1eshipping_hydrogen_liquefaction\x94\x89\x8c\x1bshipping_average_efficiency\x94G?\xd9\x99\x99\x99\x99\x99\x9a\x8c\x17shipping_hydrogen_share\x94}\x94(\x8c\x07BU_2030\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07AP_2030\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07NZ_2030\x94G?\xb9\x99\x99\x99\x99\x99\x9a\x8c\x07DF_2030\x94G?\xa9\x99\x99\x99\x99\x99\x9a\x8c\x07AB_2030\x94G?\xa9\x99\x99\x99\x99\x99\x9a\x8c\x07BU_2050\x94G\x00\x00\x00\x00\x00\x00\x00\x00\x8c\x07AP_2050\x94G?\xd0\x00\x00\x00\x00\x00\x00\x8c\x07NZ_2050\x94G?\xd7\n=p\xa3\xd7\n\x8c\x07DF_2050\x94G?\xbe\xb8Q\xeb\x85\x1e\xb8u\x8c\x15airport_sizing_factor\x94K\x03\x8c\x15international_bunkers\x94\x89\x8c\x0bco2_network\x94\x88\x8c\x1bco2_sequestration_potential\x94K\xc8\x8c\x16co2_sequestration_cost\x94K\n\x8c\x0bmethanation\x94\x88\x8c\x07helmeth\x94\x88\x8c\x03dac\x94\x88\x8c\x0bcc_fraction\x94G?\xec\xcc\xcc\xcc\xcc\xcc\xcd\x8c\x02cc\x94\x88\x8c\x0ffischer_tropsch\x94\x88\x8c\x1dmin_part_load_fischer_tropsch\x94G?\xec\xcc\xcc\xcc\xcc\xcc\xcd\x8c\x14industry_util_factor\x94G?\xe6ffffff\x8c\x1befficiency_heat_oil_to_elec\x94G?\xec\xcc\xcc\xcc\xcc\xcc\xcd\x8c\x1fefficiency_heat_biomass_to_elec\x94G?\xec\xcc\xcc\xcc\xcc\xcc\xcd\x8c\x1befficiency_heat_gas_to_elec\x94G?\xec\xcc\xcc\xcc\xcc\xcc\xcd\x8c\x17conventional_generation\x94}\x94(\x8c\x04OCGT\x94\x8c\x03gas\x94\x8c\x04CCGT\x94\x8c\x03gas\x94\x8c\x03oil\x94\x8c\x03oil\x94\x8c\x04coal\x94\x8c\x04coal\x94\x8c\x07lignite\x94\x8c\x07lignite\x94\x8c\x07biomass\x94\x8c\x07biomass\x94u\x8c\x18keep_existing_capacities\x94\x89\x8c\x15marginal_cost_storage\x94K\x00u\x8c\x07solving\x94}\x94(\x8c\x07options\x94}\x94(\x8c\x0bformulation\x94\x8c\tkirchhoff\x94\x8c\rload_shedding\x94Kd\x8c\x0bnoisy_costs\x94\x88\x8c\x0emin_iterations\x94K\x04\x8c\x0emax_iterations\x94K\x06\x8c\rclip_p_max_pu\x94G?\x84z\xe1G\xae\x14{\x8c\x0fskip_iterations\x94\x88\x8c\x10track_iterations\x94\x89u\x8c\x06solver\x94}\x94(\x8c\x04name\x94\x8c\x06gurobi\x94\x8c\x07options\x94\x8c\x0egurobi-default\x94u\x8c\x0esolver_options\x94}\x94(\x8c\rhighs-default\x94}\x94(\x8c\x07threads\x94K\x04\x8c\x06solver\x94\x8c\x03ipm\x94\x8c\rrun_crossover\x94\x88\x8c\x12small_matrix_value\x94\x8c\x041e-6\x94\x8c\x12large_matrix_value\x94\x8c\x041e15\x94\x8c\x1cprimal_feasibility_tolerance\x94\x8c\x041e-6\x94\x8c\x1adual_feasibility_tolerance\x94\x8c\x041e-6\x94\x8c\x18ipm_optimality_tolerance\x94\x8c\x041e-6\x94\x8c\x08parallel\x94\x88\x8c\x0brandom_seed\x94K{u\x8c\x0egurobi-default\x94}\x94(\x8c\x07threads\x94K\x04\x8c\x06method\x94K\x02\x8c\tcrossover\x94K\x00\x8c\nBarConvTol\x94G>\xb0\xc6\xf7\xa0\xb5\xed\x8d\x8c\x04Seed\x94K{\x8c\x07AggFill\x94K\x00\x8c\x07PreDual\x94K\x00\x8c\x17GURO_PAR_BARDENSETHRESH\x94K\xc8u\x8c\x14gurobi-numeric-focus\x94}\x94(\x8c\x0cNumericFocus\x94K\x03\x8c\x06method\x94K\x02\x8c\tcrossover\x94K\x00\x8c\x0eBarHomogeneous\x94K\x01\x8c\nBarConvTol\x94G>\xe4\xf8\xb5\x88\xe3h\xf1\x8c\x0eFeasibilityTol\x94G?\x1a6\xe2\xeb\x1cC-\x8c\rOptimalityTol\x94G?\x1a6\xe2\xeb\x1cC-\x8c\x08ObjScale\x94G\xbf\xe0\x00\x00\x00\x00\x00\x00\x8c\x07threads\x94K\x08\x8c\x04Seed\x94K{u\x8c\x0fgurobi-fallback\x94}\x94(\x8c\tcrossover\x94K\x00\x8c\x06method\x94K\x02\x8c\x0eBarHomogeneous\x94K\x01\x8c\nBarConvTol\x94G>\xe4\xf8\xb5\x88\xe3h\xf1\x8c\x0eFeasibilityTol\x94G>\xe4\xf8\xb5\x88\xe3h\xf1\x8c\rOptimalityTol\x94G>\xe4\xf8\xb5\x88\xe3h\xf1\x8c\x04Seed\x94K{\x8c\x07threads\x94K\x08u\x8c\rcplex-default\x94}\x94(\x8c\x07threads\x94K\x04\x8c\x08lpmethod\x94K\x04\x8c\x0csolutiontype\x94K\x02\x8c\x13barrier.convergetol\x94G>\xe4\xf8\xb5\x88\xe3h\xf1\x8c\x11feasopt.tolerance\x94G>\xb0\xc6\xf7\xa0\xb5\xed\x8du\x8c\x0ccopt-default\x94}\x94(\x8c\x07Threads\x94K\x08\x8c\x08LpMethod\x94K\x02\x8c\tCrossover\x94K\x00u\x8c\x0bcbc-default\x94}\x94\x8c\x0cglpk-default\x94}\x94u\x8c\x03mem\x94M0uu\x8c\x08plotting\x94}\x94(\x8c\x03map\x94}\x94(\x8c\x07figsize\x94]\x94(K\x07K\x07e\x8c\nboundaries\x94]\x94(G\xc0$ffffffK\x1dK#KHe\x8c\x05p_nom\x94}\x94(\x8c\x0fbus_size_factor\x94G@\xe8j\x00\x00\x00\x00\x00\x8c\x10linewidth_factor\x94G@\xa7p\x00\x00\x00\x00\x00u\x8c\x0ccolor_geomap\x94}\x94(\x8c\x05ocean\x94\x8c\x05white\x94\x8c\x04land\x94\x8c\nwhitesmoke\x94uu\x8c\tcosts_max\x94K\n\x8c\x0fcosts_threshold\x94G?\xc9\x99\x99\x99\x99\x99\x9a\x8c\nenergy_max\x94M N\x8c\nenergy_min\x94J\xe0\xb1\xff\xff\x8c\x10energy_threshold\x94K\x0f\x8c\tvre_techs\x94]\x94(\x8c\x06onwind\x94\x8c\noffwind-ac\x94\x8c\noffwind-dc\x94\x8c\x05solar\x94\x8c\x03ror\x94e\x8c\nconv_techs\x94]\x94(\x8c\x04OCGT\x94\x8c\x04CCGT\x94\x8c\x07nuclear\x94\x8c\x07Nuclear\x94\x8c\x04coal\x94\x8c\x03oil\x94e\x8c\rstorage_techs\x94]\x94(\x8c\thydro+PHS\x94\x8c\x07battery\x94\x8c\x02H2\x94e\x8c\x17renewable_storage_techs\x94]\x94(\x8c\x03PHS\x94\x8c\x05hydro\x94e\x8c\rload_carriers\x94]\x94\x8c\x07AC load\x94a\x8c\x0bAC_carriers\x94]\x94(\x8c\x07AC line\x94\x8c\x0eAC transformer\x94e\x8c\rlink_carriers\x94]\x94(\x8c\x07DC line\x94\x8c\x0fConverter AC-DC\x94e\x8c\nheat_links\x94]\x94(\x8c\theat pump\x94\x8c\x10resistive heater\x94\x8c\x08CHP heat\x94\x8c\x0cCHP electric\x94\x8c\ngas boiler\x94\x8c\x11central heat pump\x94\x8c\x18central resistive heater\x94\x8c\x10central CHP heat\x94\x8c\x14central CHP electric\x94\x8c\x12central gas boiler\x94e\x8c\x0fheat_generators\x94]\x94(\x8c\ngas boiler\x94\x8c\x12central gas boiler\x94\x8c\x17solar thermal collector\x94\x8c\x1fcentral solar thermal collector\x94e\x8c\x0btech_colors\x94}\x94(\x8c\x06onwind\x94\x8c\x07#235ebc\x94\x8c\x0conshore wind\x94\x8c\x07#235ebc\x94\x8c\x07offwind\x94\x8c\x07#6895dd\x94\x8c\noffwind-ac\x94\x8c\x07#6895dd\x94\x8c\roffshore wind\x94\x8c\x07#6895dd\x94\x8c\x10offshore wind ac\x94\x8c\x07#6895dd\x94\x8c\x12offshore wind (AC)\x94\x8c\x07#6895dd\x94\x8c\noffwind-dc\x94\x8c\x07#74c6f2\x94\x8c\x10offshore wind dc\x94\x8c\x07#74c6f2\x94\x8c\x12offshore wind (DC)\x94\x8c\x07#74c6f2\x94\x8c\x04wave\x94\x8c\x07#004444\x94\x8c\x05hydro\x94\x8c\x07#08ad97\x94\x8c\thydro+PHS\x94\x8c\x07#08ad97\x94\x8c\x03PHS\x94\x8c\x07#08ad97\x94\x8c\x0fhydro reservoir\x94\x8c\x07#08ad97\x94\x8c\x10hydroelectricity\x94\x8c\x07#08ad97\x94\x8c\x03ror\x94\x8c\x07#4adbc8\x94\x8c\x0crun of river\x94\x8c\x07#4adbc8\x94\x8c\x05solar\x94\x8c\x07#f9d002\x94\x8c\x08solar PV\x94\x8c\x07#f9d002\x94\x8c\rsolar thermal\x94\x8c\x07#ffef60\x94\x8c\rsolar rooftop\x94\x8c\x07#ffef60\x94\x8c\x07biomass\x94\x8c\x07#0c6013\x94\x8c\rsolid biomass\x94\x8c\x07#06540d\x94\x8c.solid biomass for industry co2 from atmosphere\x94\x8c\x07#654321\x94\x8c(solid biomass for industry co2 to stored\x94\x8c\x07#654321\x94\x8c\x1dsolid biomass for industry CC\x94\x8c\x07#654321\x94\x8c\x06biogas\x94\x8c\x07#23932d\x94\x8c\x05waste\x94\x8c\x07#68896b\x94\x8c\ngeothermal\x94\x8c\x07#ba91b1\x94\x8c\x04OCGT\x94\x8c\x07#d35050\x94\x8c\rOCGT marginal\x94\x8c\nsandybrown\x94\x8c\tOCGT-heat\x94\x8c\x07#ee8340\x94\x8c\x04CCGT\x94\x8c\x07#b80404\x94\x8c\x03gas\x94\x8c\x07#d35050\x94\x8c\x0bnatural gas\x94\x8c\x07#d35050\x94\x8c\ngas boiler\x94\x8c\x07#ee8340\x94\x8c\x0bgas boilers\x94\x8c\x07#ee8340\x94\x8c\x13gas boiler marginal\x94\x8c\x07#ee8340\x94\x8c\x11gas-to-power/heat\x94\x8c\x05brown\x94\x8c\x03SMR\x94\x8c\x07#4F4F2F\x94\x8c\x06SMR CC\x94\x8c\x08darkblue\x94\x8c\x03oil\x94\x8c\x07#262626\x94\x8c\noil boiler\x94\x8c\x07#B5A642\x94\x8c\roil emissions\x94\x8c\x07#666666\x94\x8c\x10gas for industry\x94\x8c\x07#333333\x94\x8c\x13gas for industry CC\x94\x8c\x05brown\x94\x8c"gas for industry co2 to atmosphere\x94\x8c\x07#654321\x94\x8c\x1egas for industry co2 to stored\x94\x8c\x07#654321\x94\x8c\x07nuclear\x94\x8c\x07#ff9000\x94\x8c\x07Nuclear\x94\x8c\x01r\x94\x8c\x10Nuclear marginal\x94j7\x05\x00\x00\x8c\x07uranium\x94j7\x05\x00\x00\x8c\x04coal\x94\x8c\x07#707070\x94\x8c\x04Coal\x94\x8c\x01k\x94\x8c\rCoal marginal\x94j=\x05\x00\x00\x8c\x07lignite\x94\x8c\x07#9e5a01\x94\x8c\x07Lignite\x94\x8c\x04grey\x94\x8c\x10Lignite marginal\x94\x8c\x04grey\x94\x8c\x02H2\x94\x8c\x07#ea048a\x94\x8c\tH2 export\x94\x8c\x07#ea048a\x94\x8c\x0fH2 for industry\x94\x8c\x07#222222\x94\x8c\x0fH2 for shipping\x94\x8c\x07#6495ED\x94\x8c\x0fH2 liquefaction\x94\x8c\x01m\x94\x8c\x10hydrogen storage\x94\x8c\x07#ea048a\x94\x8c\x07battery\x94\x8c\tslategray\x94\x8c\x12battery discharger\x94\x8c\tslategray\x94\x8c\x0fbattery charger\x94\x8c\tslategray\x94\x8c\x12EV battery storage\x94\x8c\tslategray\x94\x8c\x0chome battery\x94\x8c\x07#614700\x94\x8c\x14home battery storage\x94\x8c\x07#614700\x94\x8c\x05lines\x94\x8c\x07#70af1d\x94\x8c\x12transmission lines\x94\x8c\x07#70af1d\x94\x8c\x02AC\x94\x8c\x07#70af1d\x94\x8c\x05AC-AC\x94\x8c\x07#70af1d\x94\x8c\x07AC line\x94\x8c\x07#70af1d\x94\x8c\x05links\x94\x8c\x07#8a1caf\x94\x8c\nHVDC links\x94\x8c\x07#8a1caf\x94\x8c\x02DC\x94\x8c\x07#8a1caf\x94\x8c\x05DC-DC\x94\x8c\x07#8a1caf\x94\x8c\x07DC link\x94\x8c\x07#8a1caf\x94\x8c\x04load\x94\x8c\x07#ff0000\x94\x8c\rload shedding\x94\x8c\x07#ff0000\x94\x8c\rElectric load\x94\x8c\x01b\x94\x8c\x0belectricity\x94j=\x05\x00\x00\x8c\x0felectric demand\x94j=\x05\x00\x00\x8c\x1delectricity distribution grid\x94\x8c\x01y\x94\x8c\x04heat\x94\x8c\x07darkred\x94\x8c\tHeat load\x94j7\x05\x00\x00\x8c\nheat pumps\x94\x8c\x07#76EE00\x94\x8c\theat pump\x94\x8c\x07#76EE00\x94\x8c\rair heat pump\x94\x8c\x07#76EE00\x94\x8c\x10ground heat pump\x94\x8c\x07#40AA00\x94\x8c\x03CHP\x94j7\x05\x00\x00\x8c\x08CHP heat\x94j7\x05\x00\x00\x8c\x0cCHP electric\x94j7\x05\x00\x00\x8c\x0bheat demand\x94\x8c\x07darkred\x94\x8c\nrural heat\x94\x8c\x07#880000\x94\x8c\x0ccentral heat\x94\x8c\x07#b22222\x94\x8c\x0edecentral heat\x94\x8c\x07#800000\x94\x8c!low-temperature heat for industry\x94\x8c\x07#991111\x94\x8c\x0cprocess heat\x94\x8c\x07#FF3333\x94\x8c\rpower-to-heat\x94\x8c\x03red\x94\x8c\x10resistive heater\x94\x8c\x04pink\x94\x8c\x08Sabatier\x94\x8c\x07#FF1493\x94\x8c\x0bmethanation\x94\x8c\x07#FF1493\x94\x8c\x0cpower-to-gas\x94\x8c\x06purple\x94\x8c\x0fpower-to-liquid\x94\x8c\tdarkgreen\x94\x8c\x07helmeth\x94\x8c\x07#7D0552\x94\x8c\x03DAC\x94\x8c\x08deeppink\x94\x8c\nco2 stored\x94\x8c\x07#123456\x94\x8c\x0cCO2 pipeline\x94\x8c\x04gray\x94\x8c\x11CO2 sequestration\x94\x8c\x07#123456\x94\x8c\x03co2\x94\x8c\x07#123456\x94\x8c\x08co2 vent\x94\x8c\x07#654321\x94\x8c\x11process emissions\x94\x8c\x07#222222\x94\x8c\x14process emissions CC\x94\x8c\x04gray\x94\x8c\x1bprocess emissions to stored\x94\x8c\x07#444444\x94\x8c\x1fprocess emissions to atmosphere\x94\x8c\x07#888888\x94\x8c\x10agriculture heat\x94\x8c\x07#D07A7A\x94\x8c\x19agriculture machinery oil\x94\x8c\x07#1e1e1e\x94\x8c#agriculture machinery oil emissions\x94\x8c\x07#111111\x94\x8c\x17agriculture electricity\x94\x8c\x07#222222\x94\x8c\x0fFischer-Tropsch\x94\x8c\x07#44DD33\x94\x8c\x15kerosene for aviation\x94\x8c\x07#44BB11\x94\x8c\x14naphtha for industry\x94\x8c\x07#44FF55\x94\x8c\x12land transport oil\x94\x8c\x07#44DD33\x94\x8c\x1cland transport oil emissions\x94\x8c\x07#666666\x94\x8c\x18land transport fuel cell\x94\x8c\x07#AAAAAA\x94\x8c\x11land transport EV\x94\x8c\x04grey\x94\x8c\x03V2G\x94\x8c\x04grey\x94\x8c\x0bBEV charger\x94\x8c\x04grey\x94\x8c\x08shipping\x94\x8c\x07#6495ED\x94\x8c\x0cshipping oil\x94\x8c\x07#6495ED\x94\x8c\x16shipping oil emissions\x94\x8c\x07#6495ED\x94\x8c\x0bwater tanks\x94\x8c\x07#BBBBBB\x94\x8c\x11hot water storage\x94\x8c\x07#BBBBBB\x94\x8c\x12hot water charging\x94\x8c\x07#BBBBBB\x94\x8c\x15hot water discharging\x94\x8c\x07#999999\x94\x8c\x06Li ion\x94\x8c\x04grey\x94\x8c\x10district heating\x94\x8c\x07#CC4E5C\x94\x8c\x0cretrofitting\x94\x8c\x06purple\x94\x8c\x15building retrofitting\x94\x8c\x06purple\x94\x8c\x17solid biomass transport\x94\x8c\x05green\x94\x8c\x0bbiomass EOP\x94\x8c\x05green\x94\x8c\x16high-temp electrolysis\x94\x8c\x07magenta\x94\x8c\x05today\x94\x8c\x07#D2691E\x94\x8c\x07Ambient\x94j=\x05\x00\x00\x8c\x17industry coal emissions\x94\x8c\x07#654321\x94\x8c\x0fagriculture oil\x94\x8c\x07#1e1e1e\x94\x8c\rgas emissions\x94\x8c\x07#666666\x94\x8c\x16industry oil emissions\x94\x8c\x07#654321\x94\x8c\x14industry electricity\x94\x8c\x07#222222\x94\x8c\x1arail transport electricity\x94\x8c\x04grey\x94\x8c\x1asolid biomass for industry\x94\x8c\x07#654321\x94\x8c\x12rail transport oil\x94\x8c\x07#44DD33\x94\x8c\x0blow voltage\x94jz\x05\x00\x00u\x8c\nnice_names\x94}\x94(\x8c\x04OCGT\x94\x8c\x0eOpen-Cycle Gas\x94\x8c\x04CCGT\x94\x8c\x12Combined-Cycle Gas\x94\x8c\noffwind-ac\x94\x8c\x12Offshore Wind (AC)\x94\x8c\noffwind-dc\x94\x8c\x12Offshore Wind (DC)\x94\x8c\x06onwind\x94\x8c\x0cOnshore Wind\x94\x8c\x05solar\x94\x8c\x05Solar\x94\x8c\x03PHS\x94\x8c\x14Pumped Hydro Storage\x94\x8c\x05hydro\x94\x8c\x0fReservoir & Dam\x94\x8c\x07battery\x94\x8c\x0fBattery Storage\x94\x8c\x02H2\x94\x8c\x02H2\x94\x8c\x05lines\x94\x8c\x12Transmission Lines\x94\x8c\x03ror\x94\x8c\x0cRun of River\x94uu\x8c\x0bdatabundles\x94}\x94(\x8c\x14bundle_tutorial_NGBJ\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02BJ\x94\x8c\x02NG\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x04data\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8c[https://zenodo.org/records/18851102/files/bundle_tutorial_NGBJ_with_gadmlike.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1XnTP6bZoVl5kFjZQlAcmjNXgazOHtFqX/view?usp=drive_link\x94u\x8c\x06output\x94]\x94(\x8c data/gebco/GEBCO_2025_sub_ice.nc\x94\x8c]data/copernicus/PROBAV_LC100_global_v3.0.1_2019-nrt_Discrete-Classification-map_EPSG-4326.tif\x94\x8c$data/gadm/gadm41_NGA/gadm41_NGA.gpkg\x94\x8c$data/gadm/gadm41_BEN/gadm41_BEN.gpkg\x94\x8c$data/gadm/gadm36_NGA/gadm36_NGA.gpkg\x94\x8c$data/gadm/gadm36_BEN/gadm36_BEN.gpkg\x94e\x8c\x11matched_countries\x94]\x94\x8c\tn_matched\x94K\x00u\x8c%bundle_tutorial_NGBJ_global_buildings\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02BJ\x94\x8c\x02NG\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x10global_buildings\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1nnseF1A740Gp0IaryeCQ8IRcEF91-aUe/view?usp=drive_link\x94s\x8c\x06output\x94]\x94(\x8c5data/global_buildings/NG_global_buildings_raw.parquet\x94\x8c5data/global_buildings/BJ_global_buildings_raw.parquet\x94ej6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x12bundle_tutorial_BW\x94}\x94(\x8c\tcountries\x94]\x94\x8c\x02BW\x94a\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x04data\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cYhttps://zenodo.org/records/18851102/files/bundle_tutorial_BW_with_gadmlike.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1AEmlgBO-6uY_MA4rzmaRJcQ-xE1Z4uHx/view?usp=drive_link\x94u\x8c\x06output\x94]\x94(\x8c data/gebco/GEBCO_2025_sub_ice.nc\x94\x8c]data/copernicus/PROBAV_LC100_global_v3.0.1_2019-nrt_Discrete-Classification-map_EPSG-4326.tif\x94\x8c$data/gadm/gadm41_BWA/gadm41_BWA.gpkg\x94\x8c$data/gadm/gadm36_BWA/gadm36_BWA.gpkg\x94ej6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x12bundle_tutorial_MA\x94}\x94(\x8c\tcountries\x94]\x94\x8c\x02MA\x94a\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x04data\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cPhttps://zenodo.org/records/18851102/files/bundle_tutorial_data_MA.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1cUei9vH3LzIYfqltaGTaRWCX6J24f1c0/view?usp=drive_link\x94u\x8c\x06output\x94]\x94(\x8c data/gebco/GEBCO_2025_sub_ice.nc\x94\x8c]data/copernicus/PROBAV_LC100_global_v3.0.1_2019-nrt_Discrete-Classification-map_EPSG-4326.tif\x94\x8c$data/gadm/gadm41_MAR/gadm41_MAR.gpkg\x94\x8c$data/gadm/gadm36_MAR/gadm36_MAR.gpkg\x94ej6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1bbundle_tutorial_hydrobasins\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AO\x94\x8c\x02BF\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BW\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CI\x94\x8c\x02CM\x94\x8c\x02CV\x94\x8c\x02DJ\x94\x8c\x02DZ\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ET\x94\x8c\x02GA\x94\x8c\x02GH\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GW\x94\x8c\x02KE\x94\x8c\x02KM\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MG\x94\x8c\x02ML\x94\x8c\x02MR\x94\x8c\x02MU\x94\x8c\x02MW\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02RW\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SL\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TN\x94\x8c\x02TZ\x94\x8c\x02UG\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x0bhydrobasins\x94\x8c\x0bdestination\x94\x8c\x10data/hydrobasins\x94\x8c\x04urls\x94}\x94\x8c\x0bhydrobasins\x94}\x94(\x8c\x08base_url\x94\x8c6https://data.hydrosheds.org/file/HydroBASINS/standard/\x94\x8c\x08suffixes\x94]\x94\x8c\x02af\x94aus\x8c\x05unzip\x94\x88\x8c\x06output\x94]\x94\x8c data/hydrobasins/hybas_world.shp\x94aj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1cbundle_cutouts_tutorial_NGBJ\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02BJ\x94\x8c\x02NG\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cUhttps://zenodo.org/records/18851102/files/bundle_cutouts_tutorial_NGBJ.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1xnomHdXf_c5STrf7jtDiuRlN2zW0FSVC/view?usp=drive_link\x94u\x8c\x06output\x94]\x94\x8c$cutouts/cutout-2013-era5-tutorial.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1abundle_cutouts_tutorial_BW\x94}\x94(\x8c\tcountries\x94]\x94\x8c\x02BW\x94a\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cShttps://zenodo.org/records/18851102/files/bundle_cutouts_tutorial_BW.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1DDQAtnIDM0FNC3vCldfHeH__IpTbyIJt/view?usp=drive_link\x94u\x8c\x06output\x94]\x94\x8c$cutouts/cutout-2013-era5-tutorial.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1abundle_cutouts_tutorial_MA\x94}\x94(\x8c\tcountries\x94]\x94\x8c\x02MA\x94a\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cShttps://zenodo.org/records/18851102/files/bundle_cutouts_tutorial_MA.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1j5v2f4E756jmDMa707QvdNJq3xM4bYUk/view?usp=drive_link\x94u\x8c\x06output\x94]\x94\x8c$cutouts/cutout-2013-era5-tutorial.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x16bundle_cutouts_test_KZ\x94}\x94(\x8c\tcountries\x94]\x94\x8c\x02KZ\x94a\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94\x8c\x06zenodo\x94\x8cShttps://zenodo.org/records/18851102/files/bundle_tutorial_cutouts_KZ.zip?download=1\x94s\x8c\x06output\x94]\x94\x8c$cutouts/cutout-2013-era5-tutorial.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1bbundle_tutorial_data_common\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AO\x94\x8c\x02BF\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BW\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CI\x94\x8c\x02CM\x94\x8c\x02CV\x94\x8c\x02DJ\x94\x8c\x02DZ\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ET\x94\x8c\x02GA\x94\x8c\x02GH\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GW\x94\x8c\x02KE\x94\x8c\x02KM\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MG\x94\x8c\x02ML\x94\x8c\x02MR\x94\x8c\x02MU\x94\x8c\x02MW\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02RW\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SL\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TN\x94\x8c\x02TZ\x94\x8c\x02UG\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x06common\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cNhttps://zenodo.org/records/18851102/files/tutorial_data_general.zip?download=1\x94\x8c\x06gdrive\x94\x8cFhttps://drive.google.com/file/d/1nRLrs_kP0qVl-IHC4BFLjpoKa3HLk2Py/view\x94u\x8c\x06output\x94]\x94(\x8c\x15data/eez/eez_v11.gpkg\x94\x8c&data/ssp2-2.6/2030/era5_2013/Africa.nc\x94\x8c$data/ssp2-2.6/2030/era5_2013/Asia.nc\x94\x8c&data/ssp2-2.6/2030/era5_2013/Europe.nc\x94\x8c,data/ssp2-2.6/2030/era5_2013/NorthAmerica.nc\x94\x8c,data/ssp2-2.6/2030/era5_2013/SouthAmerica.nc\x94\x8c\'data/ssp2-2.6/2030/era5_2013/Oceania.nc\x94\x8c@data/landcover/world_protected_area/protected_areas_tutorial.shp\x94ej6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x12bundle_hydrobasins\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x89\x8c\x08category\x94\x8c\x0bhydrobasins\x94\x8c\x0bdestination\x94\x8c\x10data/hydrobasins\x94\x8c\x04urls\x94}\x94\x8c\x0bhydrobasins\x94}\x94(\x8c\x08base_url\x94\x8c6https://data.hydrosheds.org/file/HydroBASINS/standard/\x94\x8c\x08suffixes\x94]\x94(\x8c\x02af\x94\x8c\x02ar\x94\x8c\x02as\x94\x8c\x02au\x94\x8c\x02eu\x94\x8c\x02gr\x94\x8c\x02na\x94\x8c\x02sa\x94\x8c\x02si\x94eus\x8c\x05unzip\x94\x88\x8c\x06output\x94]\x94\x8c data/hydrobasins/hybas_world.shp\x94aj6\x06\x00\x00]\x94j\x1d\x08\x00\x00aj8\x06\x00\x00K\x01u\x8c\x0fdemandcast_full\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x89\x8c\x08category\x94\x8c\tel_demand\x94\x8c\x0bdestination\x94\x8c\x0bdata/demand\x94\x8c\x04urls\x94}\x94\x8c\x06direct\x94\x8cPhttps://zenodo.org/records/18374352/files/forecasts_on_historical_period.parquet\x94s\x8c\x05unzip\x94\x89\x8c\x06output\x94]\x94\x8c2data/demand/forecasts_on_historical_period.parquet\x94aj6\x06\x00\x00]\x94j\t\t\x00\x00aj8\x06\x00\x00K\x01u\x8c\x13demandcast_tutorial\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\tel_demand\x94\x8c\x0bdestination\x94\x8c\x0bdata/demand\x94\x8c\x04urls\x94}\x94\x8c\x06direct\x94\x8cVhttps://sandbox.zenodo.org/records/493116/files/forecasts_on_historical_period.parquet\x94s\x8c\x05unzip\x94\x89\x8c\x06output\x94]\x94\x8c2data/demand/forecasts_on_historical_period.parquet\x94aj6\x06\x00\x00]\x94j\xe8\t\x00\x00aj8\x06\x00\x00K\x01u\x8c\x17bundle_irena_statistics\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x89\x8c\x08category\x94\x8c\x05irena\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94\x8c\x06direct\x94\x8cxhttps://github.com/pypsa-meets-earth/temporary_storage/raw/refs/heads/main/datasets/IRENA_Statistics_Extract_2025H2.xlsx\x94s\x8c\x06output\x94]\x94\x8c)data/IRENA_Statistics_Extract_2025H2.xlsx\x94aj6\x06\x00\x00]\x94j\xc7\n\x00\x00aj8\x06\x00\x00K\x01u\x8c bundle_irena_statistics_tutorial\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08tutorial\x94\x88\x8c\x08category\x94\x8c\x05irena\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94\x8c\x06direct\x94\x8cxhttps://github.com/pypsa-meets-earth/temporary_storage/raw/refs/heads/main/datasets/IRENA_Statistics_Extract_2025H2.xlsx\x94s\x8c\x06output\x94]\x94\x8c)data/IRENA_Statistics_Extract_2025H2.xlsx\x94aj6\x06\x00\x00]\x94j\xa5\x0b\x00\x00aj8\x06\x00\x00K\x01u\x8c\x11bundle_data_earth\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08category\x94\x8c\x06common\x94\x8c\x0bdestination\x94\x8c\x04data\x94\x8c\x04urls\x94}\x94(\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1P4uMY464lgcp--8fAEYIJbKeNmHdg1Re/view?usp=drive_link\x94\x8c\x06zenodo\x94\x8cPhttps://sandbox.zenodo.org/records/323567/files/bundle_data_earth.zip?download=1\x94u\x8c\x06output\x94]\x94(\x8c\x15data/eez/eez_v11.gpkg\x94\x8c data/gebco/GEBCO_2025_sub_ice.nc\x94\x8c]data/copernicus/PROBAV_LC100_global_v3.0.1_2019-nrt_Discrete-Classification-map_EPSG-4326.tif\x94\x8c&data/ssp2-2.6/2030/era5_2013/Africa.nc\x94\x8c$data/ssp2-2.6/2030/era5_2013/Asia.nc\x94\x8c&data/ssp2-2.6/2030/era5_2013/Europe.nc\x94\x8c,data/ssp2-2.6/2030/era5_2013/NorthAmerica.nc\x94\x8c,data/ssp2-2.6/2030/era5_2013/SouthAmerica.nc\x94\x8c\'data/ssp2-2.6/2030/era5_2013/Oceania.nc\x94ej6\x06\x00\x00]\x94j\x83\x0c\x00\x00aj8\x06\x00\x00K\x01u\x8c\x13bundle_natura_earth\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08category\x94\x8c\x06natura\x94\x8c\x0bdestination\x94\x8c\x0cdata/natura/\x94\x8c\x04urls\x94}\x94(\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1H-Y7p8UgnbEzJgo9qPc54BpDXS8loX7Y/view?usp=drive_link\x94\x8c\x06zenodo\x94\x8cNhttps://sandbox.zenodo.org/records/323567/files/natura_wpda_CC0.zip?download=1\x94u\x8c\x06output\x94]\x94\x8c\x17data/natura/natura.tiff\x94aj6\x06\x00\x00]\x94jj\r\x00\x00aj8\x06\x00\x00K\x01u\x8c\x1ebundle_cutouts_mainland_africa\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AO\x94\x8c\x02BF\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BW\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CI\x94\x8c\x02CM\x94\x8c\x02CV\x94\x8c\x02DJ\x94\x8c\x02DZ\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ET\x94\x8c\x02GA\x94\x8c\x02GH\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GW\x94\x8c\x02KE\x94\x8c\x02KM\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MG\x94\x8c\x02ML\x94\x8c\x02MR\x94\x8c\x02MU\x94\x8c\x02MW\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02RW\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SL\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TN\x94\x8c\x02TZ\x94\x8c\x02UG\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cThttps://sandbox.zenodo.org/records/323567/files/bundle_cutouts_africa.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1WHv5Dm1GtrDZj-AxJZd3T-NMIBXty3eV/view?usp=drive_link\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1bbundle_cutouts_northamerica\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AG\x94\x8c\x02BB\x94\x8c\x02BS\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02GD\x94\x8c\x02GL\x94\x8c\x02GT\x94\x8c\x02HN\x94\x8c\x02HT\x94\x8c\x02JM\x94\x8c\x02KN\x94\x8c\x02LC\x94\x8c\x02MX\x94\x8c\x02NI\x94\x8c\x02PA\x94\x8c\x02PR\x94\x8c\x02SV\x94\x8c\x02TT\x94\x8c\x02US\x94\x8c\x02VC\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cZhttps://sandbox.zenodo.org/records/418859/files/bundle_cutouts_northamerica.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1Ao_kuHssRaP1qLV-IEG91Hu7E04-nBZg/view?usp=drive_link\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x15bundle_cutouts_europe\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AL\x94\x8c\x02AT\x94\x8c\x02BA\x94\x8c\x02BE\x94\x8c\x02BG\x94\x8c\x02BY\x94\x8c\x02CH\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DK\x94\x8c\x02EE\x94\x8c\x02ES\x94\x8c\x02FI\x94\x8c\x02FR\x94\x8c\x02GB\x94\x8c\x02GR\x94\x8c\x02HR\x94\x8c\x02HU\x94\x8c\x02IE\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02LI\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MK\x94\x8c\x02MT\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02PL\x94\x8c\x02PT\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02SE\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SM\x94\x8c\x02UA\x94\x8c\x02VA\x94\x8c\x02XK\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cThttps://sandbox.zenodo.org/records/418694/files/bundle_cutouts_europe.zip?download=1\x94\x8c\x06gdrive\x94\x8cUhttps://drive.google.com/file/d/1c2-8pChoxv4CDJW01vkPpggBSWHs9Mqi/view?usp=drive_link\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x16bundle_cutouts_oceania\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AS\x94\x8c\x02AU\x94\x8c\x02FJ\x94\x8c\x02FM\x94\x8c\x02KI\x94\x8c\x02MH\x94\x8c\x02NC\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02PG\x94\x8c\x02PW\x94\x8c\x02SB\x94\x8c\x02TO\x94\x8c\x02TV\x94\x8c\x02VU\x94\x8c\x02WS\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cUhttps://sandbox.zenodo.org/records/418864/files/bundle_cutouts_oceania.zip?download=1\x94\x8c\x06gdrive\x94\x8cRhttps://drive.google.com/file/d/1R8ELkXmW8jBBUFWRY0sbf-T14SJl4EUY/view?usp=sharing\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x13bundle_cutouts_asia\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AM\x94\x8c\x02AZ\x94\x8c\x02BD\x94\x8c\x02BH\x94\x8c\x02BN\x94\x8c\x02BT\x94\x8c\x02CN\x94\x8c\x02CY\x94\x8c\x02GE\x94\x8c\x02ID\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LK\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MY\x94\x8c\x02NP\x94\x8c\x02OM\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PS\x94\x8c\x02QA\x94\x8c\x02SA\x94\x8c\x02SG\x94\x8c\x02SY\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TM\x94\x8c\x02TR\x94\x8c\x02TW\x94\x8c\x02UZ\x94\x8c\x02VN\x94\x8c\x02YE\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cRhttps://sandbox.zenodo.org/records/418866/files/bundle_cutouts_asia.zip?download=1\x94\x8c\x06gdrive\x94\x8cRhttps://drive.google.com/file/d/11-Ax9tVks7oPjrZwG5v3C0x4OmMT_Pv8/view?usp=sharing\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1bbundle_cutouts_southamerica\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AR\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02CL\x94\x8c\x02CO\x94\x8c\x02EC\x94\x8c\x02FK\x94\x8c\x02GF\x94\x8c\x02GY\x94\x8c\x02PE\x94\x8c\x02PY\x94\x8c\x02SR\x94\x8c\x02UY\x94\x8c\x02VE\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cZhttps://sandbox.zenodo.org/records/418859/files/bundle_cutouts_southamerica.zip?download=1\x94\x8c\x06gdrive\x94\x8cRhttps://drive.google.com/file/d/1Jeu2Vzoq4mNDUKSvIviN8HqSFx5gl61b/view?usp=sharing\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1abundle_cutouts_westernasia\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AE\x94\x8c\x02AM\x94\x8c\x02AZ\x94\x8c\x02BH\x94\x8c\x02CY\x94\x8c\x02GE\x94\x8c\x02IL\x94\x8c\x02IQ\x94\x8c\x02JO\x94\x8c\x02KW\x94\x8c\x02LB\x94\x8c\x02OM\x94\x8c\x02PS\x94\x8c\x02QA\x94\x8c\x02SA\x94\x8c\x02SY\x94\x8c\x02TR\x94\x8c\x02YE\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94(\x8c\x06zenodo\x94\x8cVhttps://sandbox.zenodo.org/records/418694/files/bundle_cutouts_westasia.zip?download=1\x94\x8c\x06gdrive\x94\x8cRhttps://drive.google.com/file/d/1as-fZS4Z70CfDf3bR4i9t9S5-5pBqURP/view?usp=sharing\x94u\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j8\x06\x00\x00K\x00u\x8c\x1bbundle_cutouts_northeurasia\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02BY\x94\x8c\x02EE\x94\x8c\x02GE\x94\x8c\x02KZ\x94\x8c\x02LT\x94\x8c\x02LV\x94\x8c\x02MN\x94\x8c\x02RU\x94e\x8c\x08category\x94\x8c\x07cutouts\x94\x8c\x0bdestination\x94\x8c\x07cutouts\x94\x8c\x04urls\x94}\x94\x8c\x06gdrive\x94\x8cRhttps://drive.google.com/file/d/11EzaAaP4eOPzhfKCkm0zZ6HOv-JpgZFd/view?usp=sharing\x94s\x8c\x06output\x94]\x94\x8c\x1bcutouts/cutout-2013-era5.nc\x94a\x8c\x0edisable_by_opt\x94}\x94\x8c\x0cbuild_cutout\x94]\x94\x8c\x03all\x94asj6\x06\x00\x00]\x94j2\x0f\x00\x00aj8\x06\x00\x00K\x01u\x8c\x16bundle_landcover_earth\x94}\x94(\x8c\tcountries\x94]\x94(\x8c\x02AD\x94\x8c\x02AE\x94\x8c\x02AF\x94\x8c\x02AG\x94\x8c\x02AL\x94\x8c\x02AM\x94\x8c\x02AO\x94\x8c\x02AR\x94\x8c\x02AS\x94\x8c\x02AT\x94\x8c\x02AU\x94\x8c\x02AZ\x94\x8c\x02BA\x94\x8c\x02BB\x94\x8c\x02BD\x94\x8c\x02BE\x94\x8c\x02BF\x94\x8c\x02BG\x94\x8c\x02BH\x94\x8c\x02BI\x94\x8c\x02BJ\x94\x8c\x02BN\x94\x8c\x02BO\x94\x8c\x02BR\x94\x8c\x02BS\x94\x8c\x02BT\x94\x8c\x02BW\x94\x8c\x02BY\x94\x8c\x02BZ\x94\x8c\x02CA\x94\x8c\x02CD\x94\x8c\x02CF\x94\x8c\x02CG\x94\x8c\x02CH\x94\x8c\x02CI\x94\x8c\x02CL\x94\x8c\x02CM\x94\x8c\x02CN\x94\x8c\x02CO\x94\x8c\x02CR\x94\x8c\x02CU\x94\x8c\x02CV\x94\x8c\x02CY\x94\x8c\x02CZ\x94\x8c\x02DE\x94\x8c\x02DJ\x94\x8c\x02DK\x94\x8c\x02DM\x94\x8c\x02DO\x94\x8c\x02DZ\x94\x8c\x02EC\x94\x8c\x02EE\x94\x8c\x02EG\x94\x8c\x02EH\x94\x8c\x02ER\x94\x8c\x02ES\x94\x8c\x02ET\x94\x8c\x02FI\x94\x8c\x02FJ\x94\x8c\x02FK\x94\x8c\x02FM\x94\x8c\x02FR\x94\x8c\x02GA\x94\x8c\x02GB\x94\x8c\x02GD\x94\x8c\x02GE\x94\x8c\x02GF\x94\x8c\x02GH\x94\x8c\x02GL\x94\x8c\x02GM\x94\x8c\x02GN\x94\x8c\x02GQ\x94\x8c\x02GR\x94\x8c\x02GT\x94\x8c\x02GW\x94\x8c\x02GY\x94\x8c\x02HN\x94\x8c\x02HR\x94\x8c\x02HT\x94\x8c\x02HU\x94\x8c\x02ID\x94\x8c\x02IE\x94\x8c\x02IL\x94\x8c\x02IN\x94\x8c\x02IQ\x94\x8c\x02IR\x94\x8c\x02IS\x94\x8c\x02IT\x94\x8c\x02JM\x94\x8c\x02JO\x94\x8c\x02JP\x94\x8c\x02KE\x94\x8c\x02KG\x94\x8c\x02KH\x94\x8c\x02KI\x94\x8c\x02KM\x94\x8c\x02KN\x94\x8c\x02KP\x94\x8c\x02KR\x94\x8c\x02KW\x94\x8c\x02KZ\x94\x8c\x02LA\x94\x8c\x02LB\x94\x8c\x02LC\x94\x8c\x02LI\x94\x8c\x02LK\x94\x8c\x02LR\x94\x8c\x02LS\x94\x8c\x02LT\x94\x8c\x02LU\x94\x8c\x02LV\x94\x8c\x02LY\x94\x8c\x02MA\x94\x8c\x02MC\x94\x8c\x02MD\x94\x8c\x02ME\x94\x8c\x02MG\x94\x8c\x02MH\x94\x8c\x02MK\x94\x8c\x02ML\x94\x8c\x02MM\x94\x8c\x02MN\x94\x8c\x02MR\x94\x8c\x02MT\x94\x8c\x02MU\x94\x8c\x02MV\x94\x8c\x02MW\x94\x8c\x02MX\x94\x8c\x02MY\x94\x8c\x02MZ\x94\x8c\x02NA\x94\x8c\x02NC\x94\x8c\x02NE\x94\x8c\x02NG\x94\x8c\x02NI\x94\x8c\x02NL\x94\x8c\x02NO\x94\x8c\x02NP\x94\x8c\x02NR\x94\x8c\x02NU\x94\x8c\x02NZ\x94\x8c\x02OM\x94\x8c\x02PA\x94\x8c\x02PE\x94\x8c\x02PG\x94\x8c\x02PH\x94\x8c\x02PK\x94\x8c\x02PL\x94\x8c\x02PR\x94\x8c\x02PS\x94\x8c\x02PT\x94\x8c\x02PW\x94\x8c\x02PY\x94\x8c\x02QA\x94\x8c\x02RO\x94\x8c\x02RS\x94\x8c\x02RU\x94\x8c\x02RW\x94\x8c\x02SA\x94\x8c\x02SB\x94\x8c\x02SC\x94\x8c\x02SD\x94\x8c\x02SE\x94\x8c\x02SG\x94\x8c\x02SI\x94\x8c\x02SK\x94\x8c\x02SL\x94\x8c\x02SM\x94\x8c\x02SN\x94\x8c\x02SO\x94\x8c\x02SR\x94\x8c\x02SS\x94\x8c\x02ST\x94\x8c\x02SV\x94\x8c\x02SY\x94\x8c\x02SZ\x94\x8c\x02TD\x94\x8c\x02TG\x94\x8c\x02TH\x94\x8c\x02TJ\x94\x8c\x02TL\x94\x8c\x02TM\x94\x8c\x02TN\x94\x8c\x02TO\x94\x8c\x02TR\x94\x8c\x02TT\x94\x8c\x02TV\x94\x8c\x02TW\x94\x8c\x02TZ\x94\x8c\x02UA\x94\x8c\x02UG\x94\x8c\x02US\x94\x8c\x02UY\x94\x8c\x02UZ\x94\x8c\x02VA\x94\x8c\x02VC\x94\x8c\x02VE\x94\x8c\x02VN\x94\x8c\x02VU\x94\x8c\x02WS\x94\x8c\x02XK\x94\x8c\x02YE\x94\x8c\x02ZA\x94\x8c\x02ZM\x94\x8c\x02ZW\x94e\x8c\x08category\x94\x8c\tlandcover\x94\x8c\x0bdestination\x94\x8c$data/landcover/world_protected_areas\x94\x8c\x04urls\x94}\x94\x8c\x0fprotectedplanet\x94\x8cShttps://d1gam3xoknrgr2.cloudfront.net/current/WDPA_{month:s}{year:d}_Public_shp.zip\x94s\x8c\x06output\x94]\x94\x8c&data/landcover/world_protected_areas/*\x94aj6\x06\x00\x00]\x94j\xe4\x0f\x00\x00aj8\x06\x00\x00K\x01uu\x8c\x0centsoe_token\x94N\x8c\x0egoogle_api_key\x94N\x8c\x10matching_sources\x94]\x94(\x8c\x03GEO\x94\x8c\x03GPD\x94\x8c\x03GEM\x94e\x8c\x16fully_included_sources\x94]\x94(\x8c\x03GEO\x94\x8c\x03GPD\x94\x8c\x03GEM\x94e\x8c\x11EXTERNAL_DATABASE\x94}\x94(\x8c\x11reliability_score\x94K\x05\x8c\rstore_locally\x94\x89\x8c\x02fn\x94\x8c>/data/davidef/git/pypsa-earth/resources/powerplants_osm2pm.csv\x94u\x8c\x17parallel_duke_processes\x94\x89\x8c\rprocess_limit\x94K\x02\x8c\x15remove_missing_coords\x94\x88\x8c\x10matched_data_url\x94N\x8c\x10display_net_caps\x94\x88\x8c\x0etarget_columns\x94]\x94(\x8c\x04Name\x94\x8c\x08Fueltype\x94\x8c\nTechnology\x94\x8c\x03Set\x94\x8c\x07Country\x94\x8c\x08Capacity\x94\x8c\nEfficiency\x94\x8c\x08Duration\x94\x8c\nVolume_Mm3\x94\x8c\x0bDamHeight_m\x94\x8c\x13StorageCapacity_MWh\x94\x8c\x06DateIn\x94\x8c\x0cDateRetrofit\x94\x8c\x07DateOut\x94\x8c\x03lat\x94\x8c\x03lon\x94\x8c\x03EIC\x94\x8c\tprojectID\x94e\x8c\x10target_fueltypes\x94}\x94(\x8c\x05Other\x94\x8c\x02.*\x94\x8c\rSolid Biomass\x94]\x94(\x8c\nbiological\x94\x8c\tbioenergy\x94\x8c\x0cagricultural\x94\x8c\x07biomass\x94\x8c\x0efeste biomasse\x94\x8c\x07biomasa\x94\x8c\x08biomassa\x94\x8c\x14feste biogene stoffe\x94\x8c\x07pellets\x94\x8c\x05stroh\x94\x8c\x05straw\x94e\x8c\x06Biogas\x94]\x94(\x8c\x06biogas\x94\x8c\x06biogaz\x94\x8c\tbiomethan\x94\x8c\x14gasf\xc3\xb6rmige biomasse\x94e\x8c\x07Nuclear\x94]\x94(\x8c\x07nuclear\x94\x8c\tkernkraft\x94\x8c\tatomkraft\x94\x8c\nnucl\xc3\xa9aire\x94\x8c\x07atomowa\x94\x8c\x08j\xc4\x85drowa\x94\x8c\x0bkjernekraft\x94\x8c\x05atoom\x94e\x8c\x0bNatural Gas\x94]\x94(\x8c\x04ccgt\x94\x8c\x03gas\x94\x8c\x0bnatural gas\x94\x8c\x04ocgt\x94\x8c\x03lng\x94\x8c\x0ecombined cycle\x94\x8c\nfossil gas\x94\x8c\x12mixed fossil fuels\x94\x8c\x06erdgas\x94\x8c\x0bandere gase\x94\x8c\x03gaz\x94\x8c\x0bgaz naturel\x94\x8c\x0bgas natural\x94\x8c\tnaturgass\x94\x8c\ngaz ziemny\x94\x8c\x04gass\x94\x8c\x07aardgas\x94\x8c\x0bfl\xc3\xbcssiggas\x94e\x8c\x05Hydro\x94]\x94(\x8c\x07run-off\x94\x8c\x07run off\x94\x8c\x0crun of river\x94\x8c\x0crun-of-river\x94\x8c\x03ror\x94\x8c\x05hydro\x94\x8c\x05hidro\x94\x8c\x0bhydraulique\x94\x8c\rhydroelectric\x94\x8c\x0bwasserkraft\x94\x8c\x0bwaterkracht\x94\x8c\x06wasser\x94\x8c\tvannkraft\x94\x8c\x0bvattenkraft\x94\x8c\x05wodna\x94\x8c\ridroelettrica\x94\x8c\tidraulica\x94e\x8c\tHard Coal\x94]\x94(\x8c\x04coal\x94\x8c\x04coke\x94\x8c\nsteinkohle\x94\x8c\x07houille\x94\x8c\x0bcharbon dur\x94\x8c\x05hulla\x94\x8c\x0ccarb\xc3\xb3n duro\x94\x8c\x0ccarbone duro\x94\x8c\tantracite\x94\x8c\x08steinkul\x94\x8c\x10w\xc4\x99giel kamienny\x94\x8c\tsteenkool\x94e\x8c\x07Lignite\x94]\x94(\x8c\nbrown coal\x94\x8c\x07lignite\x94\x8c\x04peat\x94\x8c\nbraunkohle\x94\x8c\x07ligni.*\x94\x8c\x08brunatny\x94\x8c\x07brunkul\x94\x8c\tbruinkool\x94e\x8c\x03Oil\x94]\x94(\x8c\x03oil\x94\x8c\x06diesel\x94\x8c\tbiodiesel\x94\x8c\x08methanol\x94\x8c\x07heiz\xc3\xb6l\x94\x8c\x07ethanol\x94\x8c\x12mineral\xc3\xb6lprodukte\x94\x8c\x03\xc3\xb6l\x94\x8c\x05fioul\x94\x8c\x06mazout\x94\x8c\x06petrol\x94\x8c\x04olio\x94\x8c\x04olej\x94\x8c\ncarburante\x94\x8c\x04olie\x94e\x8c\nGeothermal\x94h\xdc\x8c\x05Solar\x94h\xdc\x8c\x05Waste\x94]\x94(\x8c\x08abfall.*\x94\x8c\x05waste\x94\x8c\x03mva\x94\x8c\x05m\xc3\xbcll\x94\x8c\x05afval\x94\x8c\x06affald\x94\x8c\x0fenergy recovery\x94\x8c\x0cincineration\x94\x8c\nreststoffe\x94\x8c\x06refuse\x94\x8c\x08d\xc3\xa9chets\x94\x8c\x07ordures\x94\x8c\x08residuos\x94\x8c\x06basura\x94\x8c\x07rifiuti\x94\x8c\x06scarti\x94\x8c\x06odpady\x94\x8c\x07\xc5\x9bmieci\x94\x8c\x08abf\xc3\xa4lle\x94e\x8c\x04Wind\x94h\xdc\x8c\x07Battery\x94]\x94(\x8c\x10Electro-chemical\x94\x8c\x07battery\x94e\x8c\x12Mechanical Storage\x94h\xdc\x8c\x0cHeat Storage\x94h\xdc\x8c\x10Hydrogen Storage\x94h\xdcu\x8c\x0btarget_sets\x94}\x94(\x8c\x02PP\x94\x8c\x02.*\x94\x8c\x03CHP\x94]\x94(\x8c\rheizkraftwerk\x94\x8c\x03hkw\x94\x8c\x03kwk\x94\x8c\x04fhkw\x94\x8c\x03gud\x94\x8c\x02hp\x94\x8c\x04bhkw\x94\x8c\x0ccogeneration\x94\x8c\x0epower and heat\x94\x8c\x0eheat and power\x94\x8c\x03chp\x94\x8c\x05cogen\x94\x8c\x0cheat & power\x94\x8c\x0cpower & heat\x94\x8c\rcogeneraci\xc3\xb3n\x94\x8c\rcogenerazione\x94\x8c\x0bkogeneracja\x94\x8c\x1ecombinada calor y electricidad\x94\x8c\x0ekraftvarmeverk\x94\x8c\x0fkraftvarmev\xc3\xa6rk\x94\x8c\rsamproduktion\x94\x8c\rsamproduksjon\x94\x8c\x03kvv\x94\x8c\x03wkk\x94\x8c\x15warmtekrachtkoppeling\x94\x8c\x15warmte-krachtcentrale\x94e\x8c\x07Storage\x94]\x94(\x8c\x07battery\x94\x8c\x07storage\x94\x8c\x05store\x94\x8c\x08speicher\x94\x8c\x06pumped\x94eu\x8c\x13target_technologies\x94}\x94(\x8c\x04CCGT\x94]\x94(\x8c\x04ccgt\x94\x8c\x03gas\x94\x8c\x0bnatural gas\x94\x8c\x1dgasturbinen mit abhitzekessel\x94e\x8c\x04OCGT\x94]\x94(\x8c\x04ocgt\x94\x8c\x1egasturbinen ohne abhitzekessel\x94e\x8c\rSteam Turbine\x94]\x94(\x8c\x05steam\x94\x8c\x07turbine\x94\x8c\x15kondensationsmaschine\x94\x8c\x12gegendruckmaschine\x94\x8c\ndampfmotor\x94e\x8c\x11Combustion Engine\x94]\x94(\x8c\x11combustion engine\x94\x8c\x11verbrennungsmotor\x94\x8c\rstirlingmotor\x94e\x8c\x0cRun-Of-River\x94]\x94(\x8c\x07run-off\x94\x8c\x07run off\x94\x8c\x0crun of river\x94\x8c\x0crun-of-river\x94\x8c\x03ror\x94\x8c\x10laufwasseranlage\x94\x8c\nlaufwasser\x94\x8c\rabwasserkraft\x94\x8c\x11trinkwassersystem\x94\x8c\x12brauchwassersystem\x94\x8c\x06pasada\x94\x8c\x0cprzep\xc5\x82ywowa\x94\x8c\x07fluente\x94\x8c\telvekraft\x94\x8c\ndoorstroom\x94\x8c\t\xc3\xa4lvkraft\x94e\x8c\tReservoir\x94]\x94(\x8c\treservoir\x94\x8c\nr\xc3\xa9servoir\x94\x8c\x0bimpoundment\x94\x8c\ttalsperre\x94\x8c\x07stausee\x94\x8c\x14speicherwasseranlage\x94\x8c\x0espeicherwasser\x94\x8c\x07barrage\x94\x8c\x07embalse\x94\x8c\x06bacino\x94\x8c\x08zbiornik\x94\x8c\x0bmagasinverk\x94\x8c\x0cdamkraftverk\x94\x8c\x12reguleringsmagasin\x94e\x8c\x0ePumped Storage\x94]\x94(\x8c\x0cpumped hydro\x94\x8c\x06pumped\x94\x8c\x08kavernen\x94\x8c\x06bombeo\x94\x8c\nreversible\x94\x8c\nreversibel\x94\x8c\noberbecken\x94\x8c\x0bunterbecken\x94\x8c\x07pompage\x94\x8c\tpompaggio\x94\x8c\x07pompowa\x94\x8c\x0epumpekraftverk\x94e\x8c\x06Marine\x94h\xdc\x8c\x02PV\x94]\x94(\x8c\x02pv\x94\x8c\rphoto-voltaic\x94\x8c\rphoto voltaic\x94e\x8c\x03CSP\x94h\xdc\x8c\x07Onshore\x94]\x94(\x8c\x07onshore\x94\x8c\x07an land\x94\x8c\tterrestre\x94\x8c\x08landvind\x94\x8c\x08p\xc3\xa5 land\x94\x8c\x07op land\x94\x8c\x07l\xc4\x85dowy\x94\x8c\x08su terra\x94\x8c\ten tierra\x94\x8c\x08\xc3\xa0 terre\x94e\x8c\x08Offshore\x94]\x94(\x8c\x08offshore\x94\x8c\tnearshore\x94\x8c\x07auf see\x94\x8c\x06en mer\x94\x8c\x06marino\x94\x8c\x06en mar\x94\x8c\x07in mare\x94\x8c\x06morski\x94\x8c\x07havvind\x94\x8c\x08til havs\x94\x8c\tp\xc3\xa5 havet\x94\x8c\x06op zee\x94\x8c\x07zeewind\x94eu\x8c\nclean_name\x94}\x94(\x8c\x15fueltypes_with_blocks\x94]\x94\x8c\x07Nuclear\x94a\x8c\x13remove_common_words\x94\x89\x8c\x17remove_duplicated_words\x94\x88\x8c\x07replace\x94}\x94(\x8c\x01 \x94\x8c\t[^a-zA-Z]\x94h\xdc]\x94(\x8c\x01I\x94\x8c\x02II\x94\x8c\x03III\x94\x8c\x02IV\x94\x8c\x01V\x94\x8c\x02VI\x94\x8c\x03VII\x94\x8c\x04VIII\x94\x8c\x02IX\x94\x8c\x01X\x94\x8c\x02XI\x94\x8c\x06parque\x94\x8c\x05grupo\x94\x8c\x07station\x94\x8c\x05power\x94\x8c\x05plant\x94\x8c\x04unit\x94\x8c\x05block\x94\x8c\tkraftwerk\x94\x8c\rkernkraftwerk\x94\x8c\rwehrkraftwerk\x94\x8c\x0erheinkraftwerk\x94\x8c\x1agemeinschaftskernkraftwerk\x94\x8c\x06kernkw\x94\x8c\x02kw\x94\x8c\x03hkw\x94\x8c\x07nuclear\x94\x8c\x05hydro\x94\x8c\x07thermal\x94\x8c\rheizkraftwerk\x94\x8c\x06eolico\x94\x8c\x07project\x94\x8c\rhydroelectric\x94\x8c\nhydropower\x94\x8c\x0fhydroelectrique\x94\x8c\x0bhydraulique\x94\x8c\x0bembassament\x94\x8c\x06pumped\x94\x8c\x07storage\x94\x8c\x06france\x94\x8c\x07austria\x94\x8c\x06sweden\x94\x8c\x06serbia\x94\x8c\x07ukraine\x94\x8c\x0bswitzerland\x94\x8c\x08slovakia\x94\x8c\x07croatia\x94\x8c\x06poland\x94\x8c\x08slovenia\x94\x8c\x08portugal\x94\x8c\x06bosnia\x94\x8c\x03and\x94\x8c\x0bherzegovina\x94\x8c\x08bulgaria\x94\x8c\ngenerating\x94\x8c\x07romania\x94\x8c\tmacedonia\x94\x8c\x06latvia\x94\x8c\tlithuania\x94\x8c\x07hungary\x94\x8c\x02\\w\x94e\x8c\x02ss\x94\x8c\x02\xc3\x9f\x94uu\x8c\x10fuel_to_lifetime\x94}\x94(\x8c\rSolid Biomass\x94K\x14\x8c\x06Biogas\x94K\x14\x8c\nGeothermal\x94K\x0f\x8c\tHard Coal\x94K-\x8c\x05Hydro\x94Kd\x8c\x07Lignite\x94K-\x8c\x0bNatural Gas\x94K(\x8c\x07Nuclear\x94K2\x8c\x03Oil\x94K(\x8c\x05Other\x94K\x05\x8c\x05Solar\x94K\x19\x8c\x05Waste\x94K\x19\x8c\x04Wind\x94K\x19u\x8c\rfuel_to_color\x94}\x94(\x8c\x04OCGT\x94\x8c\nlightcoral\x94\x8c\x05Hydro\x94\x8c\rlightseagreen\x94\x8c\x0cPumped hydro\x94\x8c\naquamarine\x94\x8c\x0cRun-of-river\x94\x8c\rlightseagreen\x94\x8c\x03Ror\x94\x8c\rlightseagreen\x94\x8c\x07Lignite\x94\x8c\x06sienna\x94\x8c\x07Nuclear\x94\x8c\x0cmediumorchid\x94\x8c\x05Solar\x94\x8c\x04gold\x94\x8c\x07Windoff\x94\x8c\x0ecornflowerblue\x94\x8c\x06Windon\x94\x8c\x08darkblue\x94\x8c\x08Offshore\x94\x8c\x0ecornflowerblue\x94\x8c\x07Onshore\x94\x8c\x08darkblue\x94\x8c\x04Wind\x94\x8c\tsteelblue\x94\x8c\x06Biogas\x94\x8c\x0byellowgreen\x94\x8c\tBioenergy\x94\x8c\x05green\x94\x8c\rSolid Biomass\x94\x8c\x0bforestgreen\x94\x8c\x0bNatural Gas\x94\x8c\torangered\x94\x8c\x04CCGT\x94\x8c\torangered\x94\x8c\x04Coal\x94\x8c\x05black\x94\x8c\tHard Coal\x94\x8c\x07dimgray\x94\x8c\x03Oil\x94\x8c\x05black\x94\x8c\x05Other\x94\x8c\tlightgrey\x94\x8c\x05Waste\x94\x8c\x05olive\x94\x8c\nGeothermal\x94\x8c\rdarkgoldenrod\x94\x8c\x07Battery\x94\x8c\x06purple\x94\x8c\x10Hydrogen Storage\x94\x8c\x04teal\x94\x8c\x12Mechanical Storage\x94\x8c\rdarkslategray\x94\x8c\x0cHeat Storage\x94\x8c\ndarkorange\x94\x8c\x05Total\x94\x8c\x04gold\x94u\x8c\ngit_commit\x94\x8cd9713864ade7d6009dfffe11f6f5f8e259262bad6 Add Ghana (GH) country configuration to PyPSA-Earth (#1861)\x94u\x8c\x04rule\x94\x8c\x0cbuild_shapes\x94\x8c\x0fbench_iteration\x94K\x00\x8c\tscriptdir\x94\x8c-/home/lukas/Desktop/earth/pypsa-earth/scripts\x94ub.'); from snakemake.logging import logger; logger.printshellcmds = False; __real_file__ = __file__; __file__ = '/home/lukas/Desktop/earth/pypsa-earth/scripts/build_shapes.py';
######## snakemake preamble end #########
# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText:  PyPSA-Earth and PyPSA-Eur Authors
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# -*- coding: utf-8 -*-

import multiprocessing as mp
import os
import shutil
from itertools import takewhile
from operator import attrgetter

import fiona
import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
import requests
import shapely
import xarray as xr
from _helpers import (
    BASE_DIR,
    configure_logging,
    create_logger,
    save_to_geojson,
    three_2_two_digits_country,
    two_2_three_digits_country,
    two_digits_2_name_country,
)
from numba import njit
from numba.core import types
from numba.typed import Dict
from pyproj import Transformer
from rasterio.mask import mask
from rasterio.windows import Window
from shapely.geometry import MultiPolygon
from shapely.ops import transform, unary_union
from shapely.validation import make_valid
from tqdm import tqdm

logger = create_logger(__name__)


def get_GADM_filename(country_code: str) -> str:
    """
    Function to get the GADM filename given the country code.

    Parameters
    ----------
    country_code : str
        Two letter country codes of the downloaded files

    Returns
    -------
    str
        GADM filename corresponding to the country code
    """
    special_codes_GADM = {
        "XK": "XKO",  # kosovo
        "CP": "XCL",  # clipperton island
        "SX": "MAF",  # sint maartin
        "TF": "ATF",  # french southern territories
        "AX": "ALA",  # aland
        "IO": "IOT",  # british indian ocean territory
        "CC": "CCK",  # cocos island
        "NF": "NFK",  # norfolk
        "PN": "PCN",  # pitcairn islands
        "JE": "JEY",  # jersey
        "XS": "XSP",  # spratly
        "GG": "GGY",  # guernsey
        "UM": "UMI",  # united states minor outlying islands
        "SJ": "SJM",  # svalbard
        "CX": "CXR",  # Christmas island
    }

    if country_code in special_codes_GADM:
        return f"gadm41_{special_codes_GADM[country_code]}"
    else:
        return f"gadm41_{two_2_three_digits_country(country_code)}"


def download_GADM(
    country_code: str, update: bool = False, out_logging: bool = False
) -> tuple[str, str]:
    """
    Download gpkg file from GADM for a given country code.

    Parameters
    ----------
    country_code : str
        Two letter country codes of the downloaded files
    update : bool
        Update = true, forces re-download of files

    Returns
    -------
    GADM_inputfile_gpkg : str
        Path of the downloaded gpkg file
    GADM_filename : str
        Name of the gpkg file per country
    """
    GADM_filename = get_GADM_filename(country_code)
    GADM_url = f"https://geodata.ucdavis.edu/gadm/gadm4.1/gpkg/{GADM_filename}.gpkg"

    GADM_inputfile_gpkg = os.path.join(
        BASE_DIR,
        "data",
        "gadm",
        GADM_filename,
        GADM_filename + ".gpkg",
    )  # Input filepath gpkg

    if not os.path.exists(GADM_inputfile_gpkg) or update is True:
        if out_logging:
            logger.warning(
                f"Stage 5 of 5: {GADM_filename} of country {two_digits_2_name_country(country_code)} does not exist, downloading to {GADM_inputfile_gpkg}"
            )
        #  create data/osm directory
        os.makedirs(os.path.dirname(GADM_inputfile_gpkg), exist_ok=True)

        try:
            r = requests.get(GADM_url, stream=True, timeout=300)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            raise Exception(
                f"GADM server is down at {GADM_url}. Data needed for building shapes can't be extracted.\n\r"
            )
        except Exception as exception:
            raise Exception(
                f"An error happened when trying to load GADM data by {GADM_url}.\n\r"
                + str(exception)
                + "\n\r"
            )
        else:
            with open(GADM_inputfile_gpkg, "wb") as f:
                shutil.copyfileobj(r.raw, f)

    return GADM_inputfile_gpkg, GADM_filename


def filter_gadm(
    geodf: gpd.GeoDataFrame,
    layer: int,
    cc: str,
    contended_flag: str,
    output_nonstd_to_csv: bool = False,
) -> gpd.GeoDataFrame:
    """
    Function to filter the GADM geodataframe according to the contented_flag option.

    Parameters
    ----------
    geodf : gpd.GeoDataFrame
        Geodataframe to filter
    layer : int
        Layer of the geodataframe to filter
    cc : str
        Country code to filter
    contended_flag : str
        Option to treat contended areas, i.e. areas that are not assigned to the country in the GADM layer
        but are part of the country according to the country code (GID_0) of the geodataframe. The options are:
        - "drop": drop contended areas from the geodataframe
        - "set_by_country": set GID_0 of contended areas to the country code of the country (default)
    output_nonstd_to_csv : bool
        If True, outputs the non-standard rows to a csv file for debugging purposes (default False)

    Returns
    -------
    gpd.GeoDataFrame
        Filtered GADM geodataframe
    """
    # identify non standard geodf rows
    geodf_non_std = geodf[geodf["GID_0"] != two_2_three_digits_country(cc)].copy()

    if not geodf_non_std.empty:
        logger.info(
            f"Contended areas have been found for gadm layer {layer}. They will be treated according to {contended_flag} option"
        )

        # NOTE: in these options GID_0 is not changed because it is modified below
        if contended_flag == "drop":
            geodf.drop(geodf_non_std.index, inplace=True)
        elif contended_flag != "set_by_country":
            # "set_by_country" option is the default; if this elif applies, the desired option falls back to the default
            logger.warning(
                f"Value '{contended_flag}' for option contented_flag is not recognized.\n"
                + "Fallback to 'set_by_country'"
            )

    # force GID_0 to be the country code for the relevant countries
    geodf["GID_0"] = cc

    # country shape should have a single geometry
    if (layer == 0) and (geodf.shape[0] > 1):
        logger.warning(
            f"Country shape is composed by multiple shapes that are being merged in agreement to contented_flag option '{contended_flag}'"
        )
        # take the first row only to re-define geometry keeping other columns
        geodf = geodf.iloc[[0]].set_geometry([geodf.union_all()])

    # debug output to file
    if output_nonstd_to_csv and not geodf_non_std.empty:
        geodf_non_std.to_csv(
            f"resources/non_standard_gadm{layer}_{cc}_raw.csv", index=False
        )

    return geodf


def get_GADM_layer(
    country_list: list[str],
    layer_id: int,
    geo_crs: str = "EPSG:4326",
    contended_flag: str = "set_by_country",
    update: bool = False,
    outlogging: bool = False,
) -> gpd.GeoDataFrame:
    """
    Function to retrieve a specific layer id of a geopackage for a selection of
    countries.

    Parameters
    ----------
    country_list : list[str]
        List of the countries
    layer_id : int
        Layer to consider in the format GID_{layer_id}.
        When the requested layer_id is greater than the last available layer, then the last layer is selected.
        When a negative value is requested, then, the last layer is requested
    geo_crs : str
        CRS used for geographic projection, passed to GeoPandas (e.g. "EPSG:4326")
    contended_flag : str
        Option to treat contended areas, i.e. areas that are not assigned to the country in the GADM layer
        but are part of the country according to the country code (GID_0) of the geodataframe. The options are:
        - "drop": drop contended areas from the geodataframe
        - "set_by_country": set GID_0 of contended areas to the country code of the country (default)
    update : bool
        Update = true, forces re-download of files
    outlogging : bool
        If True, emits progress information via the module logger.

    Returns
    -------
    gpd.GeoDataFrame
        Geodataframe with the requested GADM layer for the selected countries
    """
    # initialization of the geoDataFrame
    geodf_list = []

    for country_code in country_list:
        # Set the current layer id (cur_layer_id) to global layer_id
        cur_layer_id = layer_id

        # download file gpkg
        file_gpkg, name_file = download_GADM(country_code, update, outlogging)

        # get layers of a geopackage
        list_layers = fiona.listlayers(file_gpkg)

        # get layer name
        if (cur_layer_id < 0) or (cur_layer_id >= len(list_layers)):
            # when layer id is negative or larger than the number of layers, select the last layer
            cur_layer_id = len(list_layers) - 1

        # read gpkg file
        geodf_temp = gpd.read_file(
            file_gpkg, layer="ADM_ADM_" + str(cur_layer_id), engine="pyogrio"
        ).to_crs(geo_crs)

        geodf_temp = filter_gadm(
            geodf=geodf_temp,
            layer=cur_layer_id,
            cc=country_code,
            contended_flag=contended_flag,
            output_nonstd_to_csv=False,
        )

        # create a subindex column that is useful
        # in the GADM processing of sub-national zones
        geodf_temp["GADM_ID"] = geodf_temp[f"GID_{cur_layer_id}"]

        # append geodataframes
        geodf_list.append(geodf_temp)

    geodf_GADM = gpd.GeoDataFrame(pd.concat(geodf_list, ignore_index=True))
    geodf_GADM.set_crs(geo_crs)

    return geodf_GADM


def _simplify_polys(
    polys: gpd.GeoDataFrame,
    minarea: float = 0.01,
    tolerance: float = 0.01,
    filterremote: bool = False,
) -> gpd.GeoDataFrame:
    """
    Function to simplify the shape polygons

    Parameters
    ----------
    polys : gpd.GeoDataFrame
        Geodataframe with the polygons to simplify
    minarea : float
        Minimum area of the polygons to keep (default 0.01)
    tolerance : float
        Tolerance for the simplification (default 0.01)
    filterremote : bool
        If True, filters out polygons that are remote from the main polygon (default False).
        Remote is defined as having a distance from the main polygon larger than the main polygon length.

    Returns
    -------
    gpd.GeoDataFrame
        Geodataframe with the simplified polygons
    """
    if isinstance(polys, MultiPolygon):
        polys = sorted(polys.geoms, key=attrgetter("area"), reverse=True)
        mainpoly = polys[0]
        mainlength = np.sqrt(mainpoly.area / (2.0 * np.pi))
        if mainpoly.area > minarea:
            polys = MultiPolygon(
                [
                    p
                    for p in takewhile(lambda p: p.area > minarea, polys)
                    if not filterremote or (mainpoly.distance(p) < mainlength)
                ]
            )
        else:
            polys = mainpoly
    return polys.simplify(tolerance=tolerance)


def countries(
    countries: list[str],
    geo_crs: str,
    contended_flag: str,
    update: bool = False,
    out_logging: bool = False,
    tolerance: float = 0.01,
    minarea: float = 0.01,
) -> gpd.GeoSeries:
    """
    Create country shapes

    Parameters
    ----------
    countries : list[str]
        List of the countries
    geo_crs : str
        CRS used for geographic projection, passed to GeoPandas (e.g. "EPSG:4326")
    contended_flag : str
        Flag indicating whether to include contended areas
    update : bool
        Update = true, forces re-download of files
    out_logging : bool
        If True, emits progress information via the module logger.
    tolerance : float
        Tolerance for the simplification (default 0.01)
    minarea : float
        Minimum area of the polygons to keep (default 0.01)

    Returns
    -------
    gpd.GeoSeries
        Geoseries with the country shapes
    """

    if out_logging:
        logger.info("Stage 1 of 5: Create country shapes")

    # download data if needed and get the layer id 0, corresponding to the countries
    df_countries = get_GADM_layer(
        countries,
        0,
        geo_crs,
        contended_flag,
        update,
        out_logging,
    )

    # select and rename columns
    df_countries = df_countries[["GID_0", "geometry"]].copy()
    df_countries.rename(columns={"GID_0": "name"}, inplace=True)

    # set index and simplify polygons
    ret_df = df_countries.set_index("name")["geometry"].map(
        lambda x: _simplify_polys(x, tolerance=tolerance, minarea=minarea)
    )

    # there may be "holes" in the countries geometry which cause troubles along the workflow
    # e.g. that is the case for enclaves like Dahagram–Angarpota for IN/BD
    ret_df = ret_df.make_valid()

    return ret_df


def country_cover(
    country_shapes: gpd.GeoSeries,
    eez_shapes: gpd.GeoSeries = None,
    out_logging: bool = False,
    distance: float = 0.02,
) -> gpd.GeoSeries:
    """
    Create a continent shape by merging the country shapes and the EEZ shapes (if provided) with a buffer.

    Parameters
    ----------
    country_shapes : gpd.GeoSeries
        Geoseries with the country shapes
    eez_shapes : gpd.GeoSeries, optional
        Geoseries with the EEZ shapes
    out_logging : bool
        If True, emits progress information via the module logger.
    distance : float
        Distance for the buffer (default 0.02)

    Returns
    -------
    gpd.GeoSeries
        Geoseries with the continent shape
    """
    if out_logging:
        logger.info("Stage 3 of 5: Merge country shapes to create continent shape")

    shapes = country_shapes.apply(lambda x: x.buffer(distance))
    shapes_list = list(shapes)
    if eez_shapes is not None:
        shapes_list += list(eez_shapes)

    extended_country_shape = make_valid(unary_union(shapes_list))

    return extended_country_shape


def load_EEZ(
    countries_codes: list[str], geo_crs: str, EEZ_gpkg: str = "./data/eez/eez_v11.gpkg"
) -> gpd.GeoDataFrame:
    """
    Function to load the database of the Exclusive Economic Zones.

    The dataset shall be downloaded independently by the user (see
    guide) or together with pypsa-earth package.

    Parameters
    ----------
    countries_codes : list[str]
        List of two-letter ISO country codes.
    geo_crs : str
        CRS used for geographic projection, passed to GeoPandas (e.g. "EPSG:4326").
    EEZ_gpkg : str, default "./data/eez/eez_v11.gpkg"
        Path to the Marine Regions *World EEZ v11* geopackage.

    Returns
    -------
    gpd.GeoDataFrame
        GeoDataFrame with the EEZ geometries.
    """
    if not os.path.exists(EEZ_gpkg):
        raise Exception(
            f"File EEZ {EEZ_gpkg} not found, please download it from https://www.marineregions.org/download_file.php?name=World_EEZ_v11_20191118_gpkg.zip and copy it in {os.path.dirname(EEZ_gpkg)}"
        )

    geodf_EEZ = gpd.read_file(EEZ_gpkg, engine="pyogrio").to_crs(geo_crs)
    geodf_EEZ.dropna(axis=0, how="any", subset=["ISO_TER1"], inplace=True)
    # [["ISO_TER1", "TERRITORY1", "ISO_SOV1", "ISO_SOV2", "ISO_SOV3", "geometry"]]
    geodf_EEZ = geodf_EEZ[["ISO_TER1", "geometry"]]
    selected_countries_codes_3D = [
        two_2_three_digits_country(x) for x in countries_codes
    ]
    geodf_EEZ = geodf_EEZ[
        [any([x in selected_countries_codes_3D]) for x in geodf_EEZ["ISO_TER1"]]
    ]
    geodf_EEZ["ISO_TER1"] = geodf_EEZ["ISO_TER1"].map(
        lambda x: three_2_two_digits_country(x)
    )
    geodf_EEZ.reset_index(drop=True, inplace=True)

    geodf_EEZ.rename(columns={"ISO_TER1": "name"}, inplace=True)

    return geodf_EEZ


def eez(
    countries: list[str],
    geo_crs: str,
    country_shapes: gpd.GeoSeries | gpd.GeoDataFrame,
    EEZ_gpkg: str,
    out_logging: bool = False,
    distance: float = 0.0,
    minarea: float = 0.01,
    tolerance: float = 0.01,
    simplify_gadm: bool = True,
) -> gpd.GeoDataFrame:
    """
    Build offshore (EEZ) shapes for the requested countries.

    The function loads EEZ geometries, unions them per country, and optionally
    simplifies them. If ``distance`` is non-zero, the onshore country
    shapes are buffered and subtracted from EEZ geometries to create an
    "offshore-only" region (e.g. to enforce a non-build coastal strip).

    Parameters
    ----------
    countries : list[str]
        Two-letter ISO country codes to process (e.g. ``["DE", "FR"]``).
    geo_crs : str
        CRS used for geographic projection, passed to GeoPandas (e.g."EPSG:4326").
        Note: buffering distances depend on the CRS units.
    country_shapes : geopandas.GeoSeries or geopandas.GeoDataFrame
        Country geometries indexed by the same two-letter ISO codes. Must be in ``geo_crs``.
    EEZ_gpkg : str
        Path to the Marine Regions *World EEZ v11* geopackage.
    out_logging : bool, default False
        If True, emits progress information via the module logger.
    distance : float, default 0.0
        Buffer distance applied to ``country_shapes`` before subtraction from
        the EEZ geometries. Units are CRS-dependent.
    minarea : float, default 0.01
        Minimum polygon area threshold used by the simplification routine.
    tolerance : float, default 0.01
        Tolerance passed to Shapely ``simplify`` via ``_simplify_polys``.
    simplify_gadm : bool, default True
        If True, simplify and validate geometries before and after the coastal
        subtraction.

    Returns
    -------
    geopandas.GeoDataFrame
        Offshore EEZ geometries indexed by country code (column ``name`` as
        index, geometry column ``geometry``). Empty/invalid geometries are
        removed.
    """
    if out_logging:
        logger.info("Stage 2 of 5: Create offshore shapes")

    # load data
    df_eez = load_EEZ(countries, geo_crs, EEZ_gpkg)

    eez_countries = [cc for cc in countries if df_eez.name.str.contains(cc).any()]
    ret_df = gpd.GeoDataFrame(
        {
            "name": eez_countries,
            "geometry": [
                df_eez.geometry.loc[df_eez.name == cc].geometry.union_all()
                for cc in eez_countries
            ],
        }
    ).set_index("name")

    if simplify_gadm:
        ret_df = ret_df.geometry.map(
            lambda x: _simplify_polys(x, minarea=minarea, tolerance=tolerance)
        )

        ret_df = ret_df.apply(lambda x: make_valid(x))

    country_shapes_with_buffer = country_shapes.buffer(distance)
    ret_df_new = ret_df.difference(country_shapes_with_buffer)

    if simplify_gadm:
        # repeat to simplify after the buffer correction
        ret_df_new = ret_df_new.map(
            lambda x: (
                x
                if x is None
                else _simplify_polys(x, minarea=minarea, tolerance=tolerance)
            )
        )
        ret_df_new = ret_df_new.apply(lambda x: x if x is None else make_valid(x))

    # Drops empty geometry
    ret_df = ret_df_new.dropna()
    ret_df = ret_df[ret_df.geometry.is_valid & ~ret_df.geometry.is_empty]

    return ret_df


def download_WorldPop(
    country_code: str,
    worldpop_method: str,
    year: int = 2020,
    update: bool = False,
    out_logging: bool = False,
    size_min: int = 300,
) -> tuple[str, str]:
    """
    Download Worldpop using either the standard method or the API method.

    Parameters
    ----------
    worldpop_method: str
         worldpop_method = "api" will use the API method to access the WorldPop 100mx100m dataset.  worldpop_method = "standard" will use the standard method to access the WorldPop 1KMx1KM dataset.
    country_code : str
        Two letter country codes of the downloaded files.
        Files downloaded from https://data.worldpop.org/ datasets WorldPop UN adjusted
    year : int
        Year of the data to download
    update : bool
        Update = true, forces re-download of files
    size_min : int
        Minimum size of each file to download

    Returns
    -------
    WorldPop_inputfile : str
        Path of the file
    WorldPop_filename : str
        Name of the file
    """
    if worldpop_method == "api":
        return download_WorldPop_API(country_code, year, update, out_logging, size_min)

    elif worldpop_method == "standard":
        return download_WorldPop_standard(
            country_code, year, update, out_logging, size_min
        )


def download_WorldPop_standard(
    country_code: str,
    year: int = 2020,
    update: bool = False,
    out_logging: bool = False,
    size_min: int = 300,
) -> tuple[str, str]:
    """
    Download tiff file for each country code using the standard method from
    worldpop datastore with 1kmx1km resolution.

    Parameters
    ----------
    country_code : str
        Two letter country codes of the downloaded files.
        Files downloaded from https://data.worldpop.org/ datasets WorldPop UN adjusted
    year : int
        Year of the data to download
    update : bool
        Update = true, forces re-download of files
    size_min : int
        Minimum size of each file to download

    Returns
    -------
    WorldPop_inputfile : str
        Path of the file
    WorldPop_filename : str
        Name of the file
    """

    if country_code == "XK":
        WorldPop_filename = f"kos_ppp_{year}_constrained.tif"
        WorldPop_urls = [
            f"https://data.worldpop.org/GIS/Population/Global_2000_2020_Constrained/2020/BSGM/KOS/{WorldPop_filename}",
            f"https://data.worldpop.org/GIS/Population/Global_2000_2020_Constrained/2020/maxar_v1/KOS/{WorldPop_filename}",
        ]
    else:
        WorldPop_filename = f"{two_2_three_digits_country(country_code).lower()}_ppp_{year}_UNadj_constrained.tif"
        # Urls used to possibly download the file
        WorldPop_urls = [
            f"https://data.worldpop.org/GIS/Population/Global_2000_2020_Constrained/2020/BSGM/{two_2_three_digits_country(country_code).upper()}/{WorldPop_filename}",
            f"https://data.worldpop.org/GIS/Population/Global_2000_2020_Constrained/2020/maxar_v1/{two_2_three_digits_country(country_code).upper()}/{WorldPop_filename}",
        ]

    WorldPop_inputfile = os.path.join(
        BASE_DIR, "data", "WorldPop", WorldPop_filename
    )  # Input filepath tif

    if not os.path.exists(WorldPop_inputfile) or update is True:
        if out_logging:
            logger.warning(
                f"Stage 3 of 5: {WorldPop_filename} does not exist, downloading to {WorldPop_inputfile}"
            )
        #  create data/osm directory
        os.makedirs(os.path.dirname(WorldPop_inputfile), exist_ok=True)

        loaded = False
        for WorldPop_url in WorldPop_urls:
            with requests.get(WorldPop_url, stream=True) as r:
                with open(WorldPop_inputfile, "wb") as f:
                    if float(r.headers["Content-length"]) > size_min:
                        shutil.copyfileobj(r.raw, f)
                        loaded = True
                        break
        if not loaded:
            logger.error(f"Stage 3 of 5: Impossible to download {WorldPop_filename}")

    return WorldPop_inputfile, WorldPop_filename


def download_WorldPop_API(
    country_code: str,
    year: int = 2020,
    update: bool = False,
    out_logging: bool = False,
    size_min: int = 300,
) -> tuple[str, str]:
    """
    Download tiff file for each country code using the api method from worldpop
    API with 100mx100m resolution.

    Parameters
    ----------
    country_code : str
        Two letter country codes of the downloaded files.
        Files downloaded from https://data.worldpop.org/ datasets WorldPop UN adjusted
    year : int
        Year of the data to download
    update : bool
        Update = true, forces re-download of files
    size_min : int
        Minimum size of each file to download

    Returns
    -------
    WorldPop_inputfile : str
        Path of the file
    WorldPop_filename : str
        Name of the file
    """

    WorldPop_filename = f"{two_2_three_digits_country(country_code).lower()}_ppp_{year}_UNadj_constrained.tif"
    # Request to get the file
    WorldPop_inputfile = os.path.join(
        BASE_DIR, "data", "WorldPop", WorldPop_filename
    )  # Input filepath tif
    os.makedirs(os.path.dirname(WorldPop_inputfile), exist_ok=True)
    year_api = int(str(year)[2:])
    loaded = False
    WorldPop_api_urls = [
        f"https://www.worldpop.org/rest/data/pop/wpgp?iso3={two_2_three_digits_country(country_code)}",
    ]
    for WorldPop_api_url in WorldPop_api_urls:
        with requests.get(WorldPop_api_url, stream=True) as r:
            WorldPop_tif_url = r.json()["data"][year_api]["files"][0]

        with requests.get(WorldPop_tif_url, stream=True) as r:
            with open(WorldPop_inputfile, "wb") as f:
                if float(r.headers["Content-length"]) > size_min:
                    shutil.copyfileobj(r.raw, f)
                    loaded = True
                    break
    if not loaded:
        logger.error(f"Stage 3 of 5: Impossible to download {WorldPop_filename}")

    return WorldPop_inputfile, WorldPop_filename


def convert_GDP(
    name_file_nc: str, year: int = 2015, out_logging: bool = False
) -> tuple[str, str]:
    """
    Function to convert the nc database of the GDP to tif, based on the work at https://doi.org/10.1038/sdata.2018.4.
    The dataset shall be downloaded independently by the user (see guide) or together with pypsa-earth package.

    Parameters
    ----------
    name_file_nc : str
        Name of the nc file containing the GDP data (e.g. "GDP_PPP_1990_2015_5arcmin_v2.nc")
    year : int
        Year of the data to convert
    out_logging : bool
        If True, emits progress information via the module logger.

    Returns
    -------
    GDP_tif : str
        Path of the converted tif file
    name_file_tif : str
        Name of the converted tif file
    """

    if out_logging:
        logger.info("Stage 5 of 5: Access to GDP raster data")

    # tif namefile
    name_file_tif = name_file_nc[:-2] + "tif"

    # path of the nc file
    GDP_nc = os.path.join(BASE_DIR, "data", "GDP", name_file_nc)  # Input filepath nc

    # path of the tif file
    GDP_tif = os.path.join(BASE_DIR, "data", "GDP", name_file_tif)  # Input filepath nc

    # Check if file exists, otherwise throw exception
    if not os.path.exists(GDP_nc):
        raise Exception(
            f"File {name_file_nc} not found, please download it from https://datadryad.org/stash/dataset/doi:10.5061/dryad.dk1j0 and copy it in {os.path.dirname(GDP_nc)}"
        )

    # open nc dataset
    GDP_dataset = xr.open_dataset(GDP_nc)

    # get the requested year of data or its closest one
    list_years = GDP_dataset["time"]
    if year not in list_years:
        if out_logging:
            logger.warning(
                f"Stage 5 of 5 GDP data of year {year} not found, selected the most recent data ({int(list_years[-1])})"
            )
        year = float(list_years[-1])

    # subset of the database and conversion to dataframe
    GDP_dataset = GDP_dataset.sel(time=year).drop("time")
    GDP_dataset.rio.to_raster(GDP_tif)

    return GDP_tif, name_file_tif


def load_GDP(
    year: int = 2015,
    update: bool = False,
    out_logging: bool = False,
    name_file_nc: str = "GDP_PPP_1990_2015_5arcmin_v2.nc",
) -> tuple[str, str]:
    """
    Function to load the database of the GDP, based on the work at https://doi.org/10.1038/sdata.2018.4.
    The dataset shall be downloaded independently by the user (see guide) or together with pypsa-earth package.

    Parameters
    ----------
    year : int
        Year of the data to load
    update : bool
        Update = true, forces re-download of files
    out_logging : bool
        If True, emits progress information via the module logger.
    name_file_nc : str
        Name of the nc file containing the GDP data (e.g. "GDP_PPP_1990_2015_5arcmin_v2.nc")

    Returns
    -------
    GDP_tif : str
        Path of the converted tif file
    name_file_tif : str
        Name of the converted tif file
    """

    if out_logging:
        logger.info("Stage 5 of 5: Access to GDP raster data")

    # path of the nc file
    name_file_tif = name_file_nc[:-2] + "tif"
    GDP_tif = os.path.join(BASE_DIR, "data", "GDP", name_file_tif)  # Input filepath tif

    if update | (not os.path.exists(GDP_tif)):
        if out_logging:
            logger.warning(
                f"Stage 5 of 5: File {name_file_tif} not found, the file will be produced by processing {name_file_nc}"
            )
        convert_GDP(name_file_nc, year, out_logging)

    return GDP_tif, name_file_tif


def generalized_mask(
    src: rasterio.io.DatasetReader, geom: shapely.geometry.base.BaseGeometry, **kwargs
) -> rasterio.io.DatasetReader:
    """
    Generalize mask function to account for Polygon and MultiPolygon

    Parameters
    ----------
    src : rasterio.io.DatasetReader
        Rasterio dataset reader object
    geom : shapely.geometry.base.BaseGeometry
        Geometry to mask the raster with. Can be a Polygon or a MultiPolygon.
    **kwargs : dict
        Additional keyword arguments to pass to rasterio.mask.mask function.

    Returns
    -------
    rasterio.io.DatasetReader
        Masked rasterio dataset reader object
    """
    if geom.geom_type == "Polygon":
        return mask(src, [geom], **kwargs)
    elif geom.geom_type == "MultiPolygon":
        return mask(src, geom.geoms, **kwargs)
    else:
        return mask(src, geom, **kwargs)


def _sum_raster_over_mask(
    shape: shapely.geometry.base.BaseGeometry, img: rasterio.io.DatasetReader
) -> float:
    """
    Function to sum the raster value within a shape.

    The raster is masked using the provided geometry, and all pixels touched
    by the geometry boundary are included (`all_touched=True`). This approach
    slightly overestimates the result, as boundary pixels are fully counted,
    but it significantly reduces computational cost.

    Parameters
    ----------
    shape : shapely.geometry.base.BaseGeometry
        Geometry to mask the raster with. Can be a Polygon or a MultiPolygon.
    img : rasterio.io.DatasetReader
        Rasterio dataset reader object

    Returns
    -------
    float
        Sum of the raster values within the shape
    """
    out_image, out_transform = generalized_mask(
        img, shape, all_touched=True, invert=False, nodata=0.0
    )
    # calculate total output in the selected geometry
    out_image[np.isnan(out_image)] = 0
    out_sum = out_image.sum()
    # out_sum = out_image.sum()/2 + out_image_int.sum()/2

    return out_sum


def add_gdp_data(
    df_gadm: gpd.GeoDataFrame,
    year: int = 2020,
    update: bool = False,
    out_logging: bool = False,
    name_file_nc: str = "GDP_PPP_1990_2015_5arcmin_v2.nc",
    nprocesses: int = 2,
    disable_progressbar: bool = False,
) -> gpd.GeoDataFrame:
    """
    Function to add gdp data to arbitrary number of shapes in a country.

    Parameters
    ----------
    df_gadm: Geodataframe with one Multipolygon per row
        - Essential column ["country", "geometry"]
        - Non-essential column ["GADM_ID"]

    Returns
    -------
    df_gadm: Geodataframe with one Multipolygon per row
        - Same columns as input
        - Includes a new column ["gdp"]
    """
    if out_logging:
        logger.info("Stage 5 of 5: Add gdp data to GADM GeoDataFrame")

    # initialize new gdp column
    df_gadm["gdp"] = 0.0

    GDP_tif, name_tif = load_GDP(year, update, out_logging, name_file_nc)

    with rasterio.open(GDP_tif) as src:
        # resample data to target shape
        tqdm_kwargs = dict(
            ascii=False,
            unit=" geometries",
            total=df_gadm.shape[0],
            desc="Compute GDP ",
        )
        for i in tqdm(df_gadm.index, **tqdm_kwargs):
            df_gadm.loc[i, "gdp"] = _sum_raster_over_mask(df_gadm.geometry.loc[i], src)
    return df_gadm


def _init_process_pop(
    df_gadm_: gpd.GeoDataFrame,
    df_tasks_: pd.DataFrame,
    dict_worldpop_file_locations_: dict,
) -> None:
    """
    Initialize the global variables for the population processing function.
    This function is called by the multiprocessing Pool to set up the global variables
    for the population processing function.

    Parameters
    ----------
    df_gadm_: gpd.GeoDataFrame
        GeoDataFrame containing the administrative boundaries
    df_tasks_: pd.DataFrame
        DataFrame containing the tasks for population processing
    dict_worldpop_file_locations_: dict
        Dictionary mapping country codes to worldpop file locations
    """
    global df_gadm, df_tasks
    df_gadm, df_tasks = df_gadm_, df_tasks_

    global dict_worldpop_file_locations
    dict_worldpop_file_locations = dict_worldpop_file_locations_


def process_function_population(row_id: int) -> pd.DataFrame:
    """
    Function that reads the task from df_tasks and executes all the methods.

    to obtain population values for the specified region

    Parameters
    ----------
    row_id: int
        integer which indicates a specific row of df_tasks

    Returns
    -------
    windowed_pop_count: pd.DataFrame
        Dataframe containing "GADM_ID" and "pop" columns
        It represents the amount of population per region (GADM_ID),
        for the settings given by the row in df_tasks
    """
    # Get the current task values
    current_row = df_tasks.iloc[row_id]

    c_code = current_row["c_code"]
    window_dimensions = current_row["window_dimensions"]
    transform = current_row["affine_transform"]
    latlong_topleft = current_row["latlong_coordinate_topleft"]
    latlong_botright = current_row["latlong_coordinate_botright"]

    # Obtain the inputfile location from dict
    WorldPop_inputfile = dict_worldpop_file_locations[c_code]
    # get subset by country code
    country_rows = df_gadm.loc[df_gadm["country"] == c_code]

    np_pop_val, np_pop_xy = get_worldpop_val_xy(WorldPop_inputfile, window_dimensions)

    # If no values are present in the current window skip the remaining steps
    if len(np_pop_val) == 0:
        return []

    # get the geomask with id mappings
    region_geomask, id_mapping = compute_geomask_region(
        country_rows, transform, window_dimensions, latlong_topleft, latlong_botright
    )

    # If no values are present in the id_mapping skip the remaining steps
    if len(id_mapping) == 0:
        return []

    # Calculate the population for each region
    windowed_pop_count = sum_values_using_geomask(
        np_pop_val, np_pop_xy, region_geomask, id_mapping
    )
    return windowed_pop_count


def get_worldpop_val_xy(
    WorldPop_inputfile: str, window_dimensions: tuple
) -> tuple[np.ndarray, np.ndarray]:
    """
    Function to extract data from .tif input file.

    Parameters
    ----------
    WorldPop_inputfile: str
        file location of worldpop file
    window_dimensions: tuple
        dimensions of window used when reading file

    Returns
    -------
    np_pop_valid: np.ndarray
        array filled with values for each nonzero pixel in the worldpop file
    np_pop_xy: np.ndarray
        array with [x,y] coordinates of the corresponding nonzero values in np_pop_valid
    """
    col_offset, row_offset, width, height = window_dimensions

    current_window = Window(col_offset, row_offset, width, height)

    # Open the file using rasterio
    with rasterio.open(WorldPop_inputfile) as src:
        # --- Process the pixels in the image for population data ---

        # Read the gray layer (1) to get an np.array of this band
        # Rasterio doesn't support lower than float32 readout
        # Hence np_pop_raster will have nbytes = 4 * width * height
        np_pop_raster = src.read(1, window=current_window)

        # Set 'nodata' values to 0
        np_pop_raster[np_pop_raster == src.nodata] = 0

        # Set np_pop_xy to pixel locations of non zero values
        np_pop_xy = np_pop_raster.nonzero()

        # Transform to get [ x, y ] array
        # np_pop_xy as 'I' (uintc), see
        # https://numpy.org/doc/stable/reference/arrays.scalars.html#numpy.uintc
        np_pop_xy = np.array([np_pop_xy[0], np_pop_xy[1]]).T.astype("I")

        # Extract the values from the locations of non zero pixels
        np_pop_valid = np_pop_raster[np_pop_xy.T[0], np_pop_xy.T[1]]

    return np_pop_valid, np_pop_xy


def compute_geomask_region(
    country_rows: gpd.GeoDataFrame,
    affine_transform: rasterio.transform.Affine,
    window_dimensions: tuple,
    latlong_topleft: list,
    latlong_botright: list,
) -> tuple[np.ndarray, pd.DataFrame]:
    """
    Function to mask geometries into np_map_ID using an incrementing counter.

    Parameters
    ----------
    country_rows: gpd.GeoDataFrame
        geoDataFrame filled with geometries and their GADM_ID
    affine_transform: rasterio.transform.Affine
        affine transform of current window
    window_dimensions: tuple
        dimensions of window used when reading file
    latlong_topleft: list
        [latitude, longitude] of top left corner of the window
    latlong_botright: list
        [latitude, longitude] of bottom right corner of the window

    Returns
    -------
    np_map_ID.astype("H"): np.ndarray
        np_map_ID contains an ID for each location (undefined is 0)
        dimensions are taken from window_dimensions, .astype("H") for memory savings
    id_result: pd.DataFrame
        DataFrame of the mapping from id (from counter) to GADM_ID
    """
    col_offset, row_offset, x_axis_len, y_axis_len = window_dimensions

    # Set an empty numpy array with the dimensions of the country .tif file
    # np_map_ID will contain an ID for each location (undefined is 0)
    # ID corresponds to a specific geometry in country_rows
    np_map_ID = np.zeros((y_axis_len, x_axis_len))

    # List to contain the mappings of id to GADM_ID
    id_to_GADM_ID = []

    # Loop the country_rows geoDataFrame
    for i in range(len(country_rows)):
        # Set the current geometry
        cur_geometry = country_rows.iloc[i]["geometry"]

        latitude_min = cur_geometry.bounds[1]
        latitude_max = cur_geometry.bounds[3]

        # Check if bounds of geometry overlap the window
        # In the following cases we can skip the rest of the loop
        # If the geometry is above the window
        if latitude_min > latlong_topleft[0]:
            continue
        # If the geometry is below the window
        if latitude_max < latlong_botright[0]:
            continue

        # Generate a mask for the specific geometry
        temp_mask = rasterio.features.geometry_mask(
            [cur_geometry],
            (y_axis_len, x_axis_len),
            transform=affine_transform,
            all_touched=True,
            invert=True,
        )

        # Map the values of counter value to np_map_ID
        np_map_ID[temp_mask] = i + 1

        # Store the id -> GADM_ID mapping
        id_to_GADM_ID.append([i + 1, country_rows.iloc[i]["GADM_ID"]])

    if len(id_to_GADM_ID) > 0:
        id_result = pd.DataFrame(id_to_GADM_ID).set_index(0)
    else:
        id_result = pd.DataFrame()

    # Return np_map_ID as type 'H' np.ushort
    # 'H' -> https://numpy.org/doc/stable/reference/arrays.scalars.html#numpy.ushort
    # This lowers memory usage, note: ID has to be within the range [0,65535]
    return np_map_ID.astype("H"), id_result


def sum_values_using_geomask(
    np_pop_val: np.ndarray,
    np_pop_xy: np.ndarray,
    region_geomask: np.ndarray,
    id_mapping: pd.DataFrame,
) -> pd.DataFrame:
    """
    Function that sums all the population values in np_pop_val into the correct
    GADM_ID It uses ``np_pop_xy`` to access the key stored in ``region_geomask[x][y]``

    The relation of this key to GADM_ID is stored in id_mapping

    Parameters
    ----------
    np_pop_val: np.ndarray
        array filled with values for each nonzero pixel in the worldpop file
    np_pop_xy: np.ndarray
        array with [x,y] coordinates of the corresponding nonzero values in np_pop_valid
    region_geomask: np.ndarray
        array with dimensions of window, values are keys that map to GADM_ID using id_mapping
    id_mapping: pd.DataFrame
        Dataframe that contains mappings of region_geomask values to GADM_IDs

    Returns
    -------
    df_pop_count: pd.DataFrame
        Dataframe with columns
            - "GADM_ID"
            - "pop" containing population of GADM_ID region
    """
    # Initialize a dictionary
    dict_id = Dict.empty(
        key_type=types.int64,
        value_type=types.int64,
    )
    dict_id[0] = 0
    counter = 1
    # Loop over ip mapping and add indices to the dictionary
    for ID_index in np.array(id_mapping.index):
        dict_id[ID_index] = counter
        counter += 1

    # Declare an array to contain population counts
    np_pop_count = np.zeros(len(id_mapping) + 1)

    # Calculate population count of region using a numba njit compiled function
    np_pop_count = loop_and_extact_val_x_y(
        np_pop_count, np_pop_val, np_pop_xy, region_geomask, dict_id
    )

    df_pop_count = pd.DataFrame(np_pop_count, columns=["pop"])
    df_pop_count["GADM_ID"] = np.append(np.array("NaN"), id_mapping.values)
    df_pop_count = df_pop_count[["GADM_ID", "pop"]]

    return df_pop_count


@njit
def loop_and_extact_val_x_y(
    np_pop_count: np.ndarray,
    np_pop_val: np.ndarray,
    np_pop_xy: np.ndarray,
    region_geomask: np.ndarray,
    dict_id: dict,
) -> np.ndarray:
    """
    Function that will be compiled using @njit (numba) It takes all the
    population values from np_pop_val and stores them in np_pop_count.

    where each location in np_pop_count is mapped to a GADM_ID through dict_id (id_mapping by extension)

    Parameters
    ----------
    np_pop_count: np.ndarray
        np.zeros array, which will store population counts
    np_pop_val: np.ndarray
        array filled with values for each nonzero pixel in the worldpop file
    np_pop_xy: np.ndarray
        array with [x,y] coordinates of the corresponding nonzero values in np_pop_valid
    region_geomask: np.ndarray
        array with dimensions of window, values are keys that map to GADM_ID using id_mapping
    dict_id: dict
        numba typed.dict containing id_mapping.index -> location in np_pop_count

    Returns
    -------
    np_pop_count: np.ndarray
        np.array containing population counts
    """
    # Loop the population data
    for i in range(len(np_pop_val)):
        cur_value = np_pop_val[i]
        cur_x, cur_y = np_pop_xy[i]

        # Set the current id to the id at the same coordinate of the geomask
        cur_id = region_geomask[int(cur_x)][int(cur_y)]

        # Add the current value to the population
        np_pop_count[dict_id[cur_id]] += cur_value

    return np_pop_count


def calculate_transform_and_coords_for_window(
    current_transform: rasterio.transform.Affine,
    window_dimensions: tuple,
    original_window=False,
) -> list:
    """
    Function which calculates the [lat,long] corners of the window given
    window_dimensions, if not(original_window) it also changes the affine
    transform to match the window.

    Parameters
    ----------
    current_transform: rasterio.transform.Affine
        affine transform of source image
    window_dimensions: tuple
        dimensions of window used when reading file
    original_window: bool
        boolean to track if window covers entire country

    Returns
    -------
    list
        A list of: [
            adjusted_transform: affine transform adjusted to window
            coordinate_topleft: [latitude, longitude] of top left corner of the window
            coordinate_botright: [latitude, longitude] of bottom right corner of the window ]
    """
    col_offset, row_offset, x_axis_len, y_axis_len = window_dimensions

    # Declare a affine transformer with given current_transform
    transformer = rasterio.transform.AffineTransformer(current_transform)

    # Obtain the coordinates of the upper left corner of window
    window_topleft_longitude, window_topleft_latitude = transformer.xy(
        row_offset, col_offset
    )

    # Obtain the coordinates of the bottom right corner of window
    window_botright_longitude, window_botright_latitude = transformer.xy(
        row_offset + y_axis_len, col_offset + x_axis_len
    )

    if original_window:
        # If the window covers the entire country then use original affine transform
        adjusted_transform = current_transform
    else:
        # Set the adjusted transform to the correct lat and long
        adjusted_transform = rasterio.Affine(
            current_transform[0],
            current_transform[1],
            window_topleft_longitude,
            current_transform[3],
            current_transform[4],
            window_topleft_latitude,
        )

    coordinate_topleft = [window_topleft_latitude, window_topleft_longitude]
    coordinate_botright = [window_botright_latitude, window_botright_longitude]

    return [adjusted_transform, coordinate_topleft, coordinate_botright]


def generate_df_tasks(
    c_code: str, mem_read_limit_per_process: int, WorldPop_inputfile: str
) -> pd.DataFrame:
    """
    Function to generate a list of tasks based on the memory constraints.

    One task represents a single window of the image

    Parameters
    ----------
    c_code: str
        country code
    mem_read_limit_per_process: int
        memory limit for src.read() operation
    WorldPop_inputfile: str
        file location of worldpop file

    Returns
    -------
    pd.DataFrame
        Dataframe of task_list
    """
    task_list = []

    # Read out dimensions and transform of image
    with rasterio.open(WorldPop_inputfile) as src:
        worldpop_y_dim, worldpop_x_dim = src.shape
        transform = src.meta["transform"]
        block_y_dim, block_x_dim = [int(i) for i in src.block_shapes[0]]

    # Rasterio doesn't support lower than float32 readout
    # Hence reading the file will take up: nbytes = 4 * y_dim * x_dim
    expected_bytes_input_read = 4 * worldpop_y_dim * worldpop_x_dim

    # Introduce a limit that avoids overfilling RAM during readout
    # Ensure worldpop_byte_limit >= 883 * 10**6 (minimum memory for 'US')
    worldpop_byte_limit = max(883, mem_read_limit_per_process) * 10**6

    if expected_bytes_input_read < worldpop_byte_limit:
        # If the rasterio read will be within byte limit
        bool_original_window = True
        # Set the window to entire image dimensions
        current_window = [0, 0, worldpop_x_dim, worldpop_y_dim]
        # Get latlong coordinates of window
        transform_and_coords = calculate_transform_and_coords_for_window(
            transform, current_window, bool_original_window
        )
        task_list.append(
            [c_code, current_window, bool_original_window] + transform_and_coords
        )
    else:
        # Reading operation has to be split up into multiple windows
        bool_original_window = False
        # Set the windows x dimension to the input x dimension (width)
        window_x_dim = worldpop_x_dim
        # From testing we can assume max x dimension will always fit in memory:
        #   Largest memory requirement is 'US' at ~882.1 MB = 4 * 512 * window_x_dim
        #   Hence worldpop_byte_limit has to be greater than 883 MB

        # As the window spans the x dimension, set column offset to 0
        window_col_offset = 0

        # Calculate the bytes for reading the window using window_x_dim (readout is float32)
        read_block_size = 4 * block_y_dim * window_x_dim

        # Calculate the amount of blocks that fit into the memory budget
        # Using the calculated x dimension
        window_block_count = int(worldpop_byte_limit // read_block_size)

        # Multiply the y_dimension by the amount of blocks in the window
        # window_y_dim will be height of the window
        window_y_dim = window_block_count * block_y_dim

        # Calculate row offsets for all windows
        window_row_offset = np.arange(0, worldpop_y_dim, window_y_dim)

        # Loop the windows and add task for each one to task_list
        for row_offset in window_row_offset:
            current_window = [window_col_offset, row_offset, window_x_dim, window_y_dim]

            transform_and_coords = calculate_transform_and_coords_for_window(
                transform, current_window, bool_original_window
            )

            task_list.append(
                [c_code, current_window, bool_original_window] + transform_and_coords
            )

    return pd.DataFrame(task_list)


def add_population_data(
    df_gadm: gpd.GeoDataFrame,
    country_codes: list,
    worldpop_method: str,
    year: int = 2020,
    update: bool = False,
    out_logging: bool = False,
    mem_read_limit_per_process: int = 1024,
    nprocesses: int = 2,
    disable_progressbar: bool = False,
) -> gpd.GeoDataFrame:
    """
    Function to add population data to arbitrary number of shapes in a country.
    It loads data from WorldPop raster files where each pixel represents the
    population in that square region. Each square polygon (or pixel) is then
    mapped into the corresponding GADM shape. Then the population in a GADM
    shape is identified by summing over all pixels mapped to that region.

    This is performed with an iterative approach:

    1. All necessary WorldPop data tiff file are downloaded
    2. The so-called windows are created to handle RAM limitations related to large WorldPop files.
       Large WorldPop files require significant RAM to handle, which may not be available,
       hence, the entire activity is decomposed into multiple windows (or tasks).
       Each window represents a subset of a raster file on which the following algorithm is applied.
       Note: when enough RAM is available only a window is created for efficiency purposes.
    3. Execute all tasks by summing the values of the pixels mapped into each GADM shape.
       Parallelization applies in this task.

    Parameters
    ----------
    df_gadm: gpd.GeoDataFrame
        Geodataframe with one Multipolygon per row
        - Essential column ["country", "geometry"]
        - Non-essential column ["GADM_ID"]
    country_codes: list
        List of country codes to download and process
    worldpop_method: str
        Method to download worldpop data, either "api" or "ftp"
    year: int
        Year of the data to download
    update: bool
        Update = true, forces re-download of files
    out_logging: bool
        If True, emits progress information via the module logger.
    mem_read_limit_per_process: int
        Memory limit for src.read() operation in MB, used to determine window size
    nprocesses: int
        Number of processes to use for parallelization, default is 2
    disable_progressbar: bool
        If True, disables the progress bar, default is False

    Returns
    -------
    df_gadm: gpd.GeoDataFrame
        Geodataframe with one Multipolygon per row
        - Same columns as input
        - Includes a new column ["pop"]
    """

    # Initialize new population column
    df_gadm["pop"] = 0.0

    # Initialize new dict to hold worldpop_inputfile strings
    dict_worldpop_file_locations = {}

    # Initialize new dataframe to hold tasks for processing
    df_tasks = pd.DataFrame()

    if out_logging:
        logger.info(
            "Stage 3 of 5: Download WorldPop datasets, method: " + str(worldpop_method)
        )

    tqdm_kwargs_download = dict(
        ascii=False,
        desc="Downloading worldpop file per country and assigning tasks",
    )
    with tqdm(total=len(country_codes), **tqdm_kwargs_download) as pbar:
        for c_code in country_codes:
            # Download worldpop image (if required) and get file location
            WorldPop_inputfile, WorldPop_filename = download_WorldPop(
                c_code, worldpop_method, year, update, out_logging
            )
            dict_worldpop_file_locations[c_code] = WorldPop_inputfile

            # Given the memory constraint, generate a task for all windows to cover the country (c_code)
            df_new_tasks = generate_df_tasks(
                c_code, mem_read_limit_per_process, WorldPop_inputfile
            )

            df_tasks = pd.concat([df_tasks, df_new_tasks], ignore_index=True)

            pbar.update(1)

    df_tasks.columns = [
        "c_code",
        "window_dimensions",
        "is_original_window",
        "affine_transform",
        "latlong_coordinate_topleft",
        "latlong_coordinate_botright",
    ]

    if out_logging:
        logger.info("Stage 4 of 5: Add population data to GADM GeoDataFrame")

    if out_logging:
        logger.info("Stage 4 of 5: Starting multiprocessing")

    tqdm_kwargs_compute = dict(
        ascii=False, desc="Compute population per window", unit=" window"
    )
    lock = mp.Lock()
    kwargs = {
        "initializer": _init_process_pop,
        "initargs": (
            df_gadm,
            df_tasks,
            dict_worldpop_file_locations,
        ),
        "processes": nprocesses,
    }
    # Spawn processes with the parameters from kwargs
    with mp.get_context("spawn").Pool(**kwargs) as pool:
        # Create a progress bar
        with tqdm(total=len(df_tasks), **tqdm_kwargs_compute) as pbar:
            # Give the pool a workload
            for df_pop_count in pool.imap_unordered(
                process_function_population, range(len(df_tasks))
            ):
                # Acquire the lock before accessing df_gadm and pbar
                with lock:
                    # Loop the regions and write population to df_gadm
                    for i in range(len(df_pop_count)):
                        gadm_id, pop_count = df_pop_count.iloc[i]
                        # Select the row with the same "GADM_ID" and set the population count
                        df_gadm.loc[df_gadm["GADM_ID"] == gadm_id, "pop"] += pop_count

                    # update bar
                    pbar.update(1)


def gadm(
    worldpop_method: str,
    gdp_method: str,
    countries: list,
    geo_crs: str,
    contended_flag: bool,
    mem_mb: int,
    layer_id: int = 2,
    update: bool = False,
    out_logging: bool = False,
    year: int = 2020,
    nprocesses: int = None,
    simplify_gadm: bool = True,
    tolerance: float = 0.01,
    minarea: float = 0.01,
) -> gpd.GeoDataFrame:
    """
    Function to create a GeoDataFrame with GADM shapes and population and gdp data.

    Parameters
    ----------
    worldpop_method: str
        Method to download worldpop data, either "api" or "ftp"
    gdp_method: str
        Method to download gdp data, either "api" or "ftp"
    countries: list
        List of country codes to download and process
    geo_crs: str
        CRS used for geographic projection, passed to GeoPandas
    contended_flag: bool
        If True, includes contended territories in the GADM layer, which may have overlapping geometries.
        If False, contended territories are excluded.
    mem_mb: int
        Memory limit in megabytes for processing WorldPop data, used to determine window size for population data processing
    layer_id: int
        GADM layer ID to download, default is 2 (admin level 2)
    update: bool
        Update = true, forces re-download of files
    out_logging: bool
        If True, emits progress information via the module logger.
    year: int
        Year of the data to download
    nprocesses: int
        Number of processes to use for parallelization, default is None (uses os.cpu_count())
    simplify_gadm: bool
        If True, simplifies the geometries in the GADM GeoDataFrame to reduce file size and speed up processing, default is True
    tolerance: float
        Tolerance parameter for geometry simplification, default is 0.01 (units depend on the CRS of the geometries)
    minarea: float
        Minimum area threshold for geometry simplification, geometries smaller than this area will be removed after simplification,
        default is 0.01 (units depend on the CRS of the geometries)

    Returns
    -------
    gpd.GeoDataFrame
        GeoDataFrame with one Multipolygon per row, indexed by "GADM_ID"
        - Essential columns: ["country", "geometry"]
        - Optional columns: ["gdp", "pop"] (if gdp_method and worldpop_method are not False, respectively)
    """
    if out_logging:
        logger.info("Stage 3 of 5: Creation GADM GeoDataFrame")

    # download data if needed and get the desired layer_id
    df_gadm = get_GADM_layer(countries, layer_id, geo_crs, contended_flag, update)

    # select and rename columns
    df_gadm.rename(columns={"GID_0": "country"}, inplace=True)

    # drop useless columns
    df_gadm.drop(
        df_gadm.columns.difference(["country", "GADM_ID", "geometry"]),
        axis=1,
        inplace=True,
        errors="ignore",
    )

    if worldpop_method != False:
        mem_read_limit_per_process = mem_mb / nprocesses
        # add the population data to the dataset
        add_population_data(
            df_gadm,
            countries,
            worldpop_method,
            year,
            update,
            out_logging,
            mem_read_limit_per_process,
            nprocesses=nprocesses,
        )

    if gdp_method != False:
        # add the gdp data to the dataset
        add_gdp_data(
            df_gadm,
            year,
            update,
            out_logging,
            name_file_nc="GDP_PPP_1990_2015_5arcmin_v2.nc",
        )

    # renaming 3 letter to 2 letter ISO code before saving GADM file
    # In the case of a contested territory in the form 'Z00.00_0', save 'AA.00_0'
    # Include bugfix for the case of 'XXX00_0' where the "." is missing, such as for Ghana
    df_gadm["GADM_ID"] = df_gadm["country"] + df_gadm["GADM_ID"].str[3:].apply(
        lambda x: x if x.find(".") == 0 else "." + x
    )
    df_gadm.set_index("GADM_ID", inplace=True)
    idx_duplicated = df_gadm.index.duplicated(keep=False)
    if idx_duplicated.any():
        all_duplicated = idx_duplicated.sum()
        list_duplicated = df_gadm.index[idx_duplicated].unique()
        n_duplicated = df_gadm.index.duplicated(keep="first").sum()
        logger.warning(
            f"Duplicated GADM_ID found, dissolving {all_duplicated} geometries with the same GADM_ID into {n_duplicated} shapes: {list_duplicated}"
        )
        df_gadm = df_gadm.dissolve(by=df_gadm.index)

    if simplify_gadm:
        df_gadm["geometry"] = df_gadm["geometry"].map(
            lambda x: _simplify_polys(x, tolerance=tolerance, minarea=minarea)
        )
    df_gadm.geometry = df_gadm.geometry.apply(
        lambda r: make_valid(r) if not r.is_valid else r
    )
    df_gadm = df_gadm[df_gadm.geometry.is_valid & ~df_gadm.geometry.is_empty]

    return df_gadm


def crop_country(
    gadm_shapes: gpd.GeoDataFrame, subregion_config: dict[str, list[str]]
) -> gpd.GeoDataFrame:
    """
    Merge GADM administrative units into custom subregions and aggregate remaining units at the country level,
    returning combined geometries.

    Parameters
    ----------
    gadm_shapes : GeoDataFrame
        GeoDataFrame of GADM units indexed by administrative ID, containing a ``country`` column and a valid CRS.
    subregion_config : dict[str, list[str]]
        Mapping of subregion names to lists of GADM index values to be merged into each subregion.

    Returns
    -------
    GeoDataFrame
        GeoDataFrame indexed by name with merged subregion and country geometries,
        preserving the input CRS.
    """

    country_shapes_new = gpd.GeoDataFrame(columns=["name", "geometry"]).set_index(
        "name"
    )
    remain_gadm_shapes = gadm_shapes.copy(deep=True)

    for sub_region in subregion_config:

        region_GADM = subregion_config[sub_region]
        sub_gadm = remain_gadm_shapes.loc[remain_gadm_shapes.index.isin(region_GADM)]
        sub_geometry = sub_gadm.union_all()

        if not sub_geometry:
            logger.warning(f"No subregion shape generated for {sub_region}")
            continue

        logger.info(
            f"Created the {sub_region} subregion based on {list(sub_gadm.index)}"
        )

        sub_country_shapes = gpd.GeoDataFrame(
            {
                "name": sub_region,
                "geometry": [sub_geometry],
            }
        ).set_index("name")

        country_shapes_new = pd.concat([country_shapes_new, sub_country_shapes])

        remain_gadm_shapes = remain_gadm_shapes.loc[
            ~remain_gadm_shapes.index.isin(region_GADM)
        ]

    for country in remain_gadm_shapes.country.unique():
        country_geometry_new = remain_gadm_shapes.query(
            "country == @country"
        ).union_all()
        country_shapes_country = gpd.GeoDataFrame(
            {
                "name": country,
                "geometry": [country_geometry_new],
            }
        ).set_index("name")

        country_shapes_new = pd.concat([country_shapes_new, country_shapes_country])

    return gpd.GeoDataFrame(
        country_shapes_new,
        crs=gadm_shapes.crs,
        geometry=country_shapes_new.geometry,
    )


def generate_points_every_km(
    gdf: gpd.GeoDataFrame,
    distance_crs: str = "EPSG:3857",
    interval_km: float = 100,
) -> gpd.GeoDataFrame:
    """
    Generate perimeter points for each Polygon/MultiPolygon in a GeoDataFrame

    Parameters
    ----------
    gdf : GeoDataFrame
        GeoDataFrame containing Polygon or MultiPolygon geometries.
    distance_crs : str
        Projected CRS in meters for distance calculation.
    interval_km : float
        Target spacing between consecutive points in kilometers.

    Returns
    -------
    GeoDataFrame
        GeoDataFrame of sampled points with a column 'name'
        preserving the original index of the input geometry.
    """

    if gdf.crs is None:
        raise ValueError("Input GeoDataFrame must have a CRS defined.")

    interval_m = interval_km * 1000
    geo_crs = gdf.crs

    # Transformer objects
    forward_transformer = Transformer.from_crs(geo_crs, distance_crs, always_xy=True)
    backward_transformer = Transformer.from_crs(distance_crs, geo_crs, always_xy=True)

    output_rows = []

    for idx, row in gdf.iterrows():
        geometry = row.geometry

        # Project geometry to metric CRS
        projected_geom = transform(forward_transformer.transform, geometry)

        if projected_geom.geom_type == "Polygon":
            polygons = [projected_geom]
        elif projected_geom.geom_type == "MultiPolygon":
            polygons = list(projected_geom.geoms)
        else:
            continue  # skip non-polygon geometries

        for poly in polygons:
            ring = poly.exterior
            total_length = ring.length

            current_distance_along = 0
            current_point = ring.interpolate(0)

            output_rows.append(
                {
                    "name": idx,
                    "geometry": transform(
                        backward_transformer.transform, current_point
                    ),
                }
            )

            step_resolution = 1000  # meters

            while current_distance_along < total_length:
                search_distance = current_distance_along + step_resolution
                found_next = False

                while search_distance <= total_length:
                    candidate = ring.interpolate(search_distance)

                    if current_point.distance(candidate) >= interval_m:
                        current_point = candidate
                        current_distance_along = search_distance

                        output_rows.append(
                            {
                                "name": idx,
                                "geometry": transform(
                                    backward_transformer.transform, candidate
                                ),
                            }
                        )

                        found_next = True
                        break

                    search_distance += step_resolution

                if not found_next:
                    break

    # Create output GeoDataFrame
    points_gdf = gpd.GeoDataFrame(
        output_rows,
        geometry="geometry",
        crs=geo_crs,
    )
    points_gdf.index.name = "points"

    return points_gdf


def determine_subregion_country(
    subregion_shapes: gpd.GeoDataFrame,
    country_shapes: gpd.GeoDataFrame,
    distance_crs: str,
) -> dict[str, str]:
    """
    Assign each subregion to the country with which it has the largest spatial overlap.

    Parameters
    ----------
    subregion_shapes : GeoDataFrame
        GeoDataFrame indexed by subregion name containing onshore geometries with a defined CRS.
    country_shapes : GeoDataFrame
        GeoDataFrame of country geometries used to determine which country each subregion belongs to, with a defined CRS.
    distance_crs : str
        Projected CRS used for accurate area calculations, passed to GeoPandas for area computation.

    Returns
    -------
    dict[str, str]
        Mapping of subregion name to country name, where each subregion is assigned to the country with which it has the largest spatial overlap.
    """
    intersections = gpd.overlay(
        subregion_shapes.reset_index(),
        country_shapes.reset_index(),
        how="intersection",
        keep_geom_type=False,
    )

    intersections["overlap_area"] = intersections.to_crs(distance_crs).geometry.area
    idx = intersections.groupby("name_1")["overlap_area"].idxmax()
    largest = intersections.loc[idx]

    return largest.set_index("name_1")["name_2"].to_dict()


def crop_offshore(
    subregion_shapes: gpd.GeoDataFrame,
    country_shapes: gpd.GeoDataFrame,
    offshore_shapes: gpd.GeoSeries,
    distance_crs: str = "EPSG:3857",
) -> gpd.GeoDataFrame:
    """
    Split offshore (EEZ) geometries among subregions of the same country,
    assigning each subregion a portion of the country's offshore area.

    Parameters
    ----------
    subregion_shapes : GeoDataFrame
        GeoDataFrame indexed by subregion name containing onshore geometries with a defined CRS.
    country_shapes : GeoDataFrame
        GeoDataFrame of country geometries used to determine which country each subregion belongs to.
    offshore_shapes : GeoSeries
        GeoSeries indexed by name containing offshore (e.g., EEZ) geometries to be partitioned.
    distance_crs : str, default "EPSG:3857"
        Projected CRS used for distance-based operations and Voronoi partitioning.

    Returns
    -------
    GeoDataFrame
        GeoDataFrame indexed by subregion name containing offshore geometries,
        either equal to the full country offshore area (single subregion) or Voronoi-partitioned among multiple subregions.
    """

    from build_bus_regions import voronoi

    # Determine country for each subregion
    subregion_dict = determine_subregion_country(
        subregion_shapes,
        country_shapes,
        distance_crs=distance_crs,
    )

    subregion_shapes = subregion_shapes.copy()
    subregion_shapes["country"] = subregion_shapes.index.map(subregion_dict)

    results = []

    # Group once instead of value_counts + filtering
    for country, outline in offshore_shapes.items():
        sub_shape = subregion_shapes[subregion_shapes["country"] == country].copy()

        # If only one subregion → just use outline
        if len(sub_shape) == 1:
            new_gdf = gpd.GeoDataFrame(
                geometry=[outline],
                index=sub_shape.index,
                crs=subregion_shapes.crs,
            )

        # Multiple subregions → Voronoi partition
        else:
            points_gdf = generate_points_every_km(
                sub_shape,
                distance_crs=distance_crs,
                interval_km=100,
            )

            coords = points_gdf.geometry.get_coordinates()[["x", "y"]]

            if len(coords) > 1000:
                logger.warning(
                    f"Voronoi partitioning for {country} with {len(coords)} points may be slow. "
                    "Consider increasing the `interval_km` parameter to reduce the number of points, "
                    "or set `build_shape_options: simplify_gadm:` as True."
                )

            voronoi_geoms = voronoi(coords, outline)

            points_gdf = points_gdf.copy()
            points_gdf["geometry"] = voronoi_geoms

            new_gdf = points_gdf.dissolve(by="name")
            new_gdf = new_gdf[~new_gdf.geometry.is_empty]

        results.append(new_gdf)

    if not results:
        return gpd.GeoDataFrame(
            columns=["name", "geometry"], geometry="geometry"
        ).set_index("name")

    return pd.concat(results)


if __name__ == "__main__":
    if "snakemake" not in globals():
        from _helpers import mock_snakemake

        snakemake = mock_snakemake("build_shapes")
    configure_logging(snakemake)

    out = snakemake.output

    EEZ_gpkg = snakemake.input["eez"]
    mem_mb = snakemake.resources["mem_mb"]

    countries_list = snakemake.params.countries
    geo_crs = snakemake.params.crs["geo_crs"]
    distance_crs = snakemake.params.crs["distance_crs"]

    layer_id = snakemake.params.build_shape_options["gadm_layer_id"]
    update = snakemake.params.build_shape_options["update_file"]
    out_logging = snakemake.params.build_shape_options["out_logging"]
    year = snakemake.params.build_shape_options["year"]
    nprocesses = snakemake.params.build_shape_options["nprocesses"]
    contended_flag = snakemake.params.build_shape_options["contended_flag"]
    worldpop_method = snakemake.params.build_shape_options["worldpop_method"]
    gdp_method = snakemake.params.build_shape_options["gdp_method"]
    tolerance = snakemake.params.build_shape_options["simplify_tolerance"]
    simplify_gadm = snakemake.params.build_shape_options["simplify_gadm"]
    minarea = snakemake.params.build_shape_options["minarea"]

    country_shapes = countries(
        countries_list,
        geo_crs,
        contended_flag,
        update,
        out_logging,
        tolerance=tolerance,
    )
    country_shapes.to_file(out.country_shapes)

    offshore_shapes = eez(
        countries_list,
        geo_crs,
        country_shapes,
        EEZ_gpkg,
        out_logging=out_logging,
        tolerance=tolerance,
        minarea=minarea,
        simplify_gadm=simplify_gadm,
    )

    offshore_shapes.reset_index().to_file(out.offshore_shapes)

    extended_country_shape = gpd.GeoDataFrame(
        geometry=[country_cover(country_shapes, offshore_shapes.geometry)]
    )
    extended_country_shape.reset_index().to_file(out.extended_country_shape)

    gadm_shapes = gadm(
        worldpop_method,
        gdp_method,
        countries_list,
        geo_crs,
        contended_flag,
        mem_mb,
        layer_id,
        update,
        out_logging,
        year,
        nprocesses=nprocesses,
        simplify_gadm=simplify_gadm,
        tolerance=tolerance,
        minarea=minarea,
    )

    save_to_geojson(gadm_shapes, out.gadm_shapes)

    subregion_config = snakemake.params.subregion
    subregion_method = subregion_config.get("method")

    # Prepare subregion shapes based on GADM, otherwise place empty GeoDataFrame.
    if subregion_method == "gadm":
        define_by_gadm = subregion_config["define_by_gadm"]
        subregion_shapes = crop_country(gadm_shapes, define_by_gadm)

    else:
        subregion_shapes = gpd.GeoDataFrame(
            columns=["name", "geometry"],
            geometry="geometry",
            crs=gadm_shapes.crs,
        ).set_index("name")

    save_to_geojson(subregion_shapes, out.subregion_shapes)

    # If the custom method is selected and no custom offshore path is provided,
    # generate offshore shapes from the custom subregion shapes.
    has_custom_offshore = subregion_config["path_custom_offshore"]
    if subregion_method == "custom" and not has_custom_offshore:
        custom_path = subregion_config["path_custom_shapes"]
        subregion_shapes = gpd.read_file(custom_path).set_index("name")

    if not subregion_shapes.empty:
        subregion_offshore = crop_offshore(
            subregion_shapes,
            country_shapes,
            offshore_shapes,
            distance_crs=distance_crs,
        )

    else:
        subregion_offshore = subregion_shapes  # empty

    subregion_offshore.reset_index().to_file(out.subregion_offshore)
